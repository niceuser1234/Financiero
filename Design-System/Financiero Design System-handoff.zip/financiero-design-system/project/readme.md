# Financiero — Design System

Design system for **Financiero**, a German personal-finance web app (Next.js, Tailwind, shadcn/ui) for CSV bank-statement import, AI transaction categorization, contracts/subscriptions, and analytics. UI language: **German**.

## Sources given
- Screenshots of the current *unstyled* app: `uploads/pasted-1784468044736-0.png` (Analyse), `uploads/pasted-1784468053495-0.png` (Verträge), `uploads/pasted-1784468062595-0.png` (Dashboard). These define the **information architecture**, which must be preserved exactly. Visual design is fully new.
- Finanzguru inspiration screenshots: `uploads/IMG_1333.PNG`, `uploads/IMG_1336.PNG`, `uploads/IMG_1337.PNG` — mood reference only. **Not to be copied.** Its purple/mint/emoji language is explicitly out of scope.
- No codebase or Figma was accessible; no logo asset was provided.

## Information architecture (preserve exactly)
Sidebar nav (desktop): **Dashboard · Transaktionen · Verträge · Analyse · Einstellungen**. Mobile uses a bottom tab bar instead of the sidebar.
- **Dashboard**: KPI row (Gesamtsaldo, Einnahmen/Monat, Ausgaben/Monat, Abos/Monat), Ausgaben nach Kategorie, Konten, Anstehende Abbuchungen, "Jetzt synchronisieren".
- **Transaktionen**: Suche, Filter, aktive Filter-Chips, Datumsgruppen, Summenzeile.
- **Verträge**: summary card (Abos & Verträge / pro Monat / N aktiv), segmented (Aktiv/Einnahmen/Beendet), contract cards.
- **Analyse**: Zeitraum-Toggle (Monat/3 Monate/1 Jahr), KPI Einnahmen/Ausgaben, Ausgaben nach Kategorie (donut), Einnahmen vs. Ausgaben (6 Monate, bars), Top-Händler.
- **Einstellungen**: Bankverbindungen, CSV-Import, Review-Queue.

## CHOSEN DIRECTION (locked by user)
"Soft Depth" layout + **Marine** accent.
- Background: warm creme `#FBF8F1`. Cards: white, floating with soft diffuse shadow (`--shadow-md`).
- Accent: **Marine `#223A7A`** (single action color). Active nav = filled marine pill with soft accent shadow.
- KPI cards use tinted backgrounds: income green tint, expense red tint.
- Radius 16–18 on cards; larger friendly display numbers in **Space Grotesk**; body/UI in **Inter**.
- Semantics: income green (`--income #1E6B48`), expense red (`--expense #C0322B`), uncategorized neutral gray, review-needed muted amber. Recurring bookings get a small repeat icon.
- Chart palette: 8 harmonized colors (marine→blue→light-blue→amber→clay→slate→bronze→olive). No purple/mint.
- **No emojis, ever.** Icons: Lucide (stroke, matches unstyled app's icon style).

Exploration files (decision aids, not part of the shipped system): `explorations/`.

## Fonts — SUBSTITUTION FLAG ⚠️
Brief asked for General Sans / Geist. General Sans is not on Google Fonts. Currently using **Inter** (UI/body) + **Space Grotesk** (display numbers/headings) via Google Fonts (`tokens/fonts.css`). **Please send licensed Geist/General Sans font files to swap in.**

---

## CONTENT FUNDAMENTALS
- **Language:** German throughout. **Address the user informally with "du/dein"** — e.g. page lead "Wofür dein Geld draufgeht.", "Überblick über deine Finanzen.", "Nichts in den nächsten 14 Tagen."
- **Tone:** calm, plain, reassuring; never salesy or hypey (the opposite of Finanzguru's "Kostenlos testen / Plus" upsell language). No exclamation marks.
- **Casing:** Sentence case for headings and body. UPPERCASE only for small eyebrow labels on KPI cards (GESAMTSALDO, EINNAHMEN, AUSGABEN) with wide letter-spacing.
- **Money:** German format — `1.043,72 €` (thousands dot, decimal comma, trailing € with a space). Negative amounts use a leading minus: `−9,99 €`. Always tabular-nums, right-aligned in tables/rows.
- **Emojis:** never. Icons only.
- **Sample data is real & German** (no lorem): DKB Girokonto 1.043,72 €; Testflix −9,99 €; REWE; Miete/Vermieter Weber −890,00 €; DB Fernverkehr; Amazon; dm; Stadtwerke; Allianz Versicherung; Spotify; Gehalt/Arbeitgeber.

## VISUAL FOUNDATIONS
- **Backgrounds:** flat warm creme `#FBF8F1`. No gradients, no imagery, no texture, no patterns. Whitespace is the primary design material.
- **Cards:** white `#FFFFFF`, radius `16px` (outer shell `18px`), soft diffuse shadow `--shadow-md` (`0 8px 24px rgba(27,31,39,.07)`); hairline border only where cards sit directly on white. Cards *float* — elevation, not borders, separates them.
- **KPI cards:** tinted background (income/expense soft bg) OR white with an eyebrow label + big Space Grotesk number.
- **Type:** Space Grotesk for page titles, section big numbers, KPI values; Inter for labels, body, rows. Tight tracking (`-0.02em`) on display numbers.
- **Color use:** exactly one accent (marine) for actions/active states. Green/red reserved strictly for income/expense amounts. Everything else is warm neutral ink.
- **Borders:** hairline `#E6E4DD`, 1px. Never colored left-border accents.
- **Shadows:** soft, warm, low-contrast, diffuse only. Accent shadow (`--shadow-accent`) reserved for active nav pill + primary button.
- **Radii:** sm 8 (chips/segmented pills), md 12 (buttons/nav/inputs), lg 16 (cards), xl 18 (shell), pill 999 (filter pills, badges).
- **Motion:** subtle. `--ease-out`, 120–180ms. Fades and small position shifts; no bounces, no playful spring.
- **Hover:** light surfaces darken slightly (`--surface-hover`); accent elements darken (`--accent-hover`). **Press:** darker still (`--accent-active`), no shrink.
- **Focus:** 2–3px accent ring (`--accent-ring`), never removed.
- **Transparency/blur:** minimal; not a core motif.

## ICONOGRAPHY
- **Lucide** (https://lucide.dev) — stroke icons, ~1.75px weight, matches the stroke icons already in the unstyled app (grid dashboard, arrows for transactions, repeat for contracts, pie for analysis, gear for settings). Loaded from CDN (`lucide@latest`).
- Nav: `layout-dashboard`, `arrow-left-right`, `repeat`, `pie-chart`, `settings`. Actions: `refresh-cw` (sync), `search`, `sliders-horizontal` (filter), `upload` (CSV), `building-2`/`landmark` (bank), `check-circle-2` (review done), `alert-triangle` (review needed).
- Recurring bookings: small `repeat` glyph inline.
- **No emoji, no unicode-symbol icons.** Merchant avatars = tinted rounded square with the merchant's initial (no fetched logos).
- Substitution flag: Lucide substitutes for whatever icon set the (inaccessible) codebase used; matches stroke style of the screenshots.

---

## INDEX / MANIFEST
- **`styles.css`** (root) — global entry; `@import`s the token files. Consumers link this one file.
- **`tokens/`** — `colors.css`, `typography.css`, `spacing.css`, `radii-shadows.css`, `fonts.css`.
- **`thumbnail.html`** (root) — homepage tile (Marine + wordmark + swatch strip).
- **`SKILL.md`** (root) — Agent-Skills-compatible entry for downloading this system into Claude Code.
- **`guidelines/`** — foundation specimen cards (Design System tab):
  - Colors: accent, surfaces, ink, semantic, charts.
  - Type: display numbers, scale, tabular figures.
  - Spacing: 8px scale, radii, elevation.
  - Brand: wordmark, voice/tone, money format.
- **`components/`** — reusable primitives, each `Name.jsx` + `Name.d.ts` + `Name.prompt.md`, one `@dsCard` html per dir. Namespace: `window.FinancieroDesignSystem_854562`.
  - `icons/` — **Icon** (Lucide path set).
  - `controls/` — **Button, SegmentedControl, FilterPill, FilterChip, SearchField**.
  - `surfaces/` — **Card, KpiCard, Badge, EmptyState**.
  - `navigation/` — **Sidebar**.
  - `data/` — **TransactionRow, DonutChart, BarChart**.
- **`ui_kits/financiero/`** — full app recreation (desktop 5 screens + mobile 2), sample German data in `data.js`. See its `README.md`.
- **`explorations/`** — direction/color decision aids (not part of the shipped system).

### Intentional additions
- **Icon** — a thin wrapper over Lucide path data, added because the app needs a single consistent stroke-icon primitive and no icon component existed in the (inaccessible) source.

### Component inventory source
Derived from brief §2 (the source codebase/Figma was not accessible). If the real repo is later attached, reconcile names/props against it — the kit wins on exact values.

### Templates (starting points for consumers)
- `templates/dashboard/Dashboard.dc.html` — Financiero dashboard scaffold (sidebar, KPI row, category donut, recent transactions), composed from the design-system components via `ds-base.js`. This is what consuming projects copy to start a new Financiero design.
