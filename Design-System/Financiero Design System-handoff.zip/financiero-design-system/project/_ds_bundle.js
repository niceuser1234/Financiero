/* @ds-bundle: {"format":4,"namespace":"FinancieroDesignSystem_854562","components":[{"name":"Button","sourcePath":"components/controls/Button.jsx"},{"name":"FilterChip","sourcePath":"components/controls/FilterChip.jsx"},{"name":"FilterPill","sourcePath":"components/controls/FilterPill.jsx"},{"name":"SearchField","sourcePath":"components/controls/SearchField.jsx"},{"name":"SegmentedControl","sourcePath":"components/controls/SegmentedControl.jsx"},{"name":"BarChart","sourcePath":"components/data/BarChart.jsx"},{"name":"DonutChart","sourcePath":"components/data/DonutChart.jsx"},{"name":"TransactionRow","sourcePath":"components/data/TransactionRow.jsx"},{"name":"ICONS","sourcePath":"components/icons/Icon.jsx"},{"name":"Icon","sourcePath":"components/icons/Icon.jsx"},{"name":"Sidebar","sourcePath":"components/navigation/Sidebar.jsx"},{"name":"Badge","sourcePath":"components/surfaces/Badge.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"EmptyState","sourcePath":"components/surfaces/EmptyState.jsx"},{"name":"KpiCard","sourcePath":"components/surfaces/KpiCard.jsx"}],"sourceHashes":{"components/controls/Button.jsx":"4049659b94ef","components/controls/FilterChip.jsx":"e59a49761891","components/controls/FilterPill.jsx":"20f2b5f90fb5","components/controls/SearchField.jsx":"b377028bd43f","components/controls/SegmentedControl.jsx":"14671f0801e9","components/data/BarChart.jsx":"d56d340cd006","components/data/DonutChart.jsx":"d11fe578b168","components/data/TransactionRow.jsx":"73fee00ed548","components/icons/Icon.jsx":"b3096259881f","components/navigation/Sidebar.jsx":"c888c21584a9","components/surfaces/Badge.jsx":"ea2b5e190d1d","components/surfaces/Card.jsx":"3f4ae3331115","components/surfaces/EmptyState.jsx":"03934ba18987","components/surfaces/KpiCard.jsx":"ff706620c314","ui_kits/financiero/Analyse.jsx":"a5d32c0bcdd9","ui_kits/financiero/Dashboard.jsx":"5239cc08f726","ui_kits/financiero/Einstellungen.jsx":"766acd8d3e35","ui_kits/financiero/Mobile.jsx":"a19d47dbe3fb","ui_kits/financiero/Shell.jsx":"db98de7c55e2","ui_kits/financiero/Transaktionen.jsx":"5cdddf580e71","ui_kits/financiero/Vertraege.jsx":"967176fbac14","ui_kits/financiero/app.jsx":"bf655ccf4056","ui_kits/financiero/data.js":"625109545958"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.FinancieroDesignSystem_854562 = window.FinancieroDesignSystem_854562 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/controls/SegmentedControl.jsx
try { (() => {
/** iOS-style segmented control. Options = [{value,label}] or string[]. One accent-filled active pill. */
function SegmentedControl({
  options = [],
  value,
  onChange,
  size = 'md',
  style
}) {
  const opts = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  const pad = size === 'sm' ? '6px 12px' : '8px 16px';
  const font = size === 'sm' ? 12.5 : 13.5;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      padding: 4,
      gap: 2,
      background: 'var(--surface)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-sm)',
      border: '1px solid var(--hairline)',
      ...style
    }
  }, opts.map(o => {
    const active = o.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: o.value,
      onClick: () => onChange && onChange(o.value),
      style: {
        border: 0,
        cursor: 'pointer',
        padding: pad,
        borderRadius: 'var(--radius-sm)',
        font: `${active ? 'var(--fw-semibold)' : 'var(--fw-medium)'} ${font}px/1 var(--font-sans)`,
        background: active ? 'var(--accent)' : 'transparent',
        color: active ? 'var(--accent-fg)' : 'var(--ink-500)',
        boxShadow: active ? 'var(--shadow-accent)' : 'none',
        transition: 'background var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)',
        whiteSpace: 'nowrap'
      },
      onMouseEnter: e => {
        if (!active) e.currentTarget.style.color = 'var(--ink-900)';
      },
      onMouseLeave: e => {
        if (!active) e.currentTarget.style.color = 'var(--ink-500)';
      }
    }, o.label);
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/data/BarChart.jsx
try { (() => {
/**
 * Grouped/single bar chart. `data` = [{label, values:[n,...]}]; `series` = [{name,color}].
 * Bars share a max scale. `highlightLast` emphasizes the final label (current period).
 */
function BarChart({
  data = [],
  series = [],
  height = 150,
  highlightLast,
  empty,
  style
}) {
  const allVals = data.flatMap(d => d.values || []);
  const max = Math.max(1, ...allVals);
  if (allVals.every(v => !v) && empty) return /*#__PURE__*/React.createElement("div", {
    style: style
  }, empty);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 18,
      height,
      paddingTop: 8
    }
  }, data.map((d, i) => {
    const last = i === data.length - 1;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 9,
        height: '100%'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        width: '100%',
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'center',
        gap: 5
      }
    }, (d.values || []).map((v, j) => /*#__PURE__*/React.createElement("div", {
      key: j,
      title: `${series[j] ? series[j].name : ''}`,
      style: {
        width: series.length > 1 ? 13 : 22,
        height: `${v / max * 100}%`,
        minHeight: v > 0 ? 3 : 0,
        borderRadius: '6px 6px 0 0',
        background: series[j] && series[j].color || 'var(--chart-1)',
        opacity: highlightLast && !last ? 0.55 : 1,
        transition: 'height var(--dur) var(--ease-out)'
      }
    }))), /*#__PURE__*/React.createElement("span", {
      style: {
        font: `${highlightLast && last ? 'var(--fw-bold)' : 'var(--fw-medium)'} 11.5px/1 var(--font-sans)`,
        color: highlightLast && last ? 'var(--ink-900)' : 'var(--ink-400)'
      }
    }, d.label));
  })), series.length > 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 18,
      marginTop: 16,
      paddingTop: 14,
      borderTop: '1px solid var(--hairline)'
    }
  }, series.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 7,
      font: `var(--fw-medium) 12.5px/1 var(--font-sans)`,
      color: 'var(--ink-500)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: 3,
      background: s.color
    }
  }), s.name))));
}
Object.assign(__ds_scope, { BarChart });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/BarChart.jsx", error: String((e && e.message) || e) }); }

// components/data/DonutChart.jsx
try { (() => {
const DEFAULT_COLORS = ['var(--chart-1)', 'var(--chart-2)', 'var(--chart-3)', 'var(--chart-4)', 'var(--chart-5)', 'var(--chart-6)', 'var(--chart-7)', 'var(--chart-8)'];

/**
 * Donut chart. `data` = [{label, value, color?}]. Renders an SVG ring + center total + legend.
 * When total is 0, shows the `empty` slot (pass an EmptyState).
 */
function DonutChart({
  data = [],
  size = 150,
  thickness = 20,
  centerLabel = 'GESAMT',
  centerValue,
  legend = true,
  empty,
  style
}) {
  const total = data.reduce((s, d) => s + (d.value || 0), 0);
  if (total <= 0 && empty) return /*#__PURE__*/React.createElement("div", {
    style: style
  }, empty);
  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  let acc = 0;
  const segs = data.map((d, i) => {
    const frac = total > 0 ? d.value / total : 0;
    const seg = {
      color: d.color || DEFAULT_COLORS[i % DEFAULT_COLORS.length],
      dash: frac * c,
      offset: -acc * c,
      ...d,
      frac
    };
    acc += frac;
    return seg;
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 26,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: size,
      height: size,
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: `0 0 ${size} ${size}`,
    style: {
      transform: 'rotate(-90deg)'
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: "var(--surface-sunken)",
    strokeWidth: thickness
  }), segs.map((s, i) => /*#__PURE__*/React.createElement("circle", {
    key: i,
    cx: size / 2,
    cy: size / 2,
    r: r,
    fill: "none",
    stroke: s.color,
    strokeWidth: thickness,
    strokeDasharray: `${s.dash} ${c - s.dash}`,
    strokeDashoffset: s.offset,
    strokeLinecap: "butt"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'grid',
      placeContent: 'center',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: `var(--fw-semibold) 9.5px/1 var(--font-sans)`,
      letterSpacing: 'var(--tracking-label)',
      color: 'var(--ink-400)'
    }
  }, centerLabel), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 3,
      font: `var(--fw-bold) 17px/1 var(--font-display)`,
      letterSpacing: '-.01em',
      color: 'var(--ink-900)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, centerValue))), legend && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 11,
      flex: 1,
      minWidth: 0
    }
  }, segs.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      font: `var(--fw-regular) 13px/1 var(--font-sans)`,
      color: 'var(--ink-700)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: 3,
      background: s.color,
      flex: 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, s.label), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--fw-semibold) 13px/1 var(--font-sans)`,
      color: 'var(--ink-900)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, s.display != null ? s.display : s.value)))));
}
Object.assign(__ds_scope, { DonutChart });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DonutChart.jsx", error: String((e && e.message) || e) }); }

// components/icons/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Lucide (ISC) icon path data, copied verbatim. 24×24, stroke, no fill.
const ICONS = {
  'layout-dashboard': '<rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/>',
  'arrow-left-right': '<path d="M8 3 4 7l4 4"/><path d="M4 7h16"/><path d="m16 21 4-4-4-4"/><path d="M20 17H4"/>',
  'repeat': '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
  'pie-chart': '<path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/>',
  'settings': '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  'refresh-cw': '<path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16"/><path d="M8 16H3v5"/>',
  'search': '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  'sliders-horizontal': '<line x1="21" x2="14" y1="4" y2="4"/><line x1="10" x2="3" y1="4" y2="4"/><line x1="21" x2="12" y1="12" y2="12"/><line x1="8" x2="3" y1="12" y2="12"/><line x1="21" x2="16" y1="20" y2="20"/><line x1="12" x2="3" y1="20" y2="20"/><line x1="14" x2="14" y1="2" y2="6"/><line x1="8" x2="8" y1="10" y2="14"/><line x1="16" x2="16" y1="18" y2="22"/>',
  'upload': '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
  'building-2': '<path d="M6 22V4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18Z"/><path d="M6 12H4a2 2 0 0 0-2 2v6a2 2 0 0 0 2 2h2"/><path d="M18 9h2a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-2"/><path d="M10 6h4"/><path d="M10 10h4"/><path d="M10 14h4"/><path d="M10 18h4"/>',
  'landmark': '<line x1="3" x2="21" y1="22" y2="22"/><line x1="6" x2="6" y1="18" y2="11"/><line x1="10" x2="10" y1="18" y2="11"/><line x1="14" x2="14" y1="18" y2="11"/><line x1="18" x2="18" y1="18" y2="11"/><polygon points="12 2 20 7 4 7"/>',
  'circle-check': '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
  'triangle-alert': '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
  'plus': '<path d="M5 12h14"/><path d="M12 5v14"/>',
  'x': '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
  'chevron-down': '<path d="m6 9 6 6 6-6"/>',
  'chevron-right': '<path d="m9 18 6-6-6-6"/>',
  'arrow-up-right': '<path d="M7 7h10v10"/><path d="M7 17 17 7"/>',
  'arrow-down-right': '<path d="m7 7 10 10"/><path d="M17 7v10H7"/>',
  'ellipsis': '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
  'calendar': '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>',
  'trash-2': '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
  'credit-card': '<rect width="20" height="14" x="2" y="5" rx="2"/><line x1="2" x2="22" y1="10" y2="10"/>',
  'wallet': '<path d="M19 7V4a1 1 0 0 0-1-1H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4h-3a2 2 0 0 0 0 4h3a1 1 0 0 0 1-1v-2a1 1 0 0 0-1-1"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/>',
  'trending-up': '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
  'trending-down': '<polyline points="22 17 13.5 8.5 8.5 13.5 2 7"/><polyline points="16 17 22 17 22 11"/>',
  'bell': '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
  'inbox': '<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
  'file-text': '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
  'plug': '<path d="M12 22v-5"/><path d="M9 8V2"/><path d="M15 8V2"/><path d="M18 8v5a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V8Z"/>',
  'log-out': '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
  'shield-check': '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>'
};

/** Inline SVG icon. `name` is a Lucide id from ICONS; `size` px; inherits color via currentColor. */
function Icon({
  name,
  size = 20,
  strokeWidth = 1.75,
  color,
  style,
  ...rest
}) {
  const d = ICONS[name];
  if (!d) return null;
  return /*#__PURE__*/React.createElement("svg", _extends({
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color || 'currentColor',
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flex: 'none',
      ...style
    },
    dangerouslySetInnerHTML: {
      __html: d
    }
  }, rest));
}
Object.assign(__ds_scope, { ICONS, Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Icon.jsx", error: String((e && e.message) || e) }); }

// components/controls/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  sm: {
    pad: '8px 14px',
    font: 13,
    gap: 6,
    icon: 15,
    radius: 'var(--radius-md)'
  },
  md: {
    pad: '11px 18px',
    font: 14,
    gap: 8,
    icon: 17,
    radius: 'var(--radius-md)'
  },
  lg: {
    pad: '13px 22px',
    font: 15,
    gap: 8,
    icon: 18,
    radius: 'var(--radius-md)'
  }
};
const VARIANTS = {
  primary: {
    background: 'var(--accent)',
    color: 'var(--accent-fg)',
    border: '1px solid transparent',
    boxShadow: 'var(--shadow-accent)'
  },
  secondary: {
    background: 'var(--surface)',
    color: 'var(--ink-900)',
    border: '1px solid var(--hairline-strong)',
    boxShadow: 'var(--shadow-xs)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--ink-700)',
    border: '1px solid transparent',
    boxShadow: 'none'
  },
  danger: {
    background: 'var(--surface)',
    color: 'var(--expense)',
    border: '1px solid var(--hairline-strong)',
    boxShadow: 'var(--shadow-xs)'
  }
};

/** Primary action button. One accent color; primary = filled marine with soft accent shadow. */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  iconRight,
  disabled,
  style,
  ...rest
}) {
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  return /*#__PURE__*/React.createElement("button", _extends({
    disabled: disabled,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      font: `var(--fw-semibold) ${s.font}px/1 var(--font-sans)`,
      letterSpacing: '.005em',
      padding: s.pad,
      borderRadius: s.radius,
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: `background var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out)`,
      opacity: disabled ? 0.45 : 1,
      whiteSpace: 'nowrap',
      ...v,
      ...style
    },
    onMouseDown: e => {
      if (!disabled && variant === 'primary') e.currentTarget.style.background = 'var(--accent-active)';
    },
    onMouseUp: e => {
      if (!disabled && variant === 'primary') e.currentTarget.style.background = 'var(--accent-hover)';
    },
    onMouseEnter: e => {
      if (!disabled && variant === 'primary') e.currentTarget.style.background = 'var(--accent-hover)';
      if (!disabled && (variant === 'secondary' || variant === 'ghost' || variant === 'danger')) e.currentTarget.style.background = 'var(--surface-hover)';
    },
    onMouseLeave: e => {
      if (!disabled) e.currentTarget.style.background = v.background;
    }
  }, rest), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: s.icon,
    strokeWidth: 2
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight,
    size: s.icon,
    strokeWidth: 2
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/Button.jsx", error: String((e && e.message) || e) }); }

// components/controls/FilterChip.jsx
try { (() => {
/** Active-filter chip with a dismiss ✕. Shows the applied filter; `onRemove` clears it. */
function FilterChip({
  label,
  value,
  onRemove,
  style
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '6px 6px 6px 12px',
      borderRadius: 'var(--radius-pill)',
      background: 'var(--accent-soft)',
      color: 'var(--accent)',
      font: `var(--fw-medium) 12.5px/1 var(--font-sans)`,
      whiteSpace: 'nowrap',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .7
    }
  }, label, ":"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--fw-semibold)'
    }
  }, value), /*#__PURE__*/React.createElement("button", {
    onClick: onRemove,
    "aria-label": "Filter entfernen",
    style: {
      display: 'grid',
      placeItems: 'center',
      width: 18,
      height: 18,
      marginLeft: 1,
      border: 0,
      borderRadius: 'var(--radius-pill)',
      cursor: 'pointer',
      background: 'transparent',
      color: 'var(--accent)',
      transition: 'background var(--dur-fast) var(--ease-out)'
    },
    onMouseEnter: e => {
      e.currentTarget.style.background = 'rgba(34,58,122,.14)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = 'transparent';
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 13,
    strokeWidth: 2.5
  })));
}
Object.assign(__ds_scope, { FilterChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/FilterChip.jsx", error: String((e && e.message) || e) }); }

// components/controls/FilterPill.jsx
try { (() => {
/** Filter pill (rounded-full). Toggleable; `count` shows a badge; `dropdown` adds a chevron. */
function FilterPill({
  children,
  active,
  count,
  dropdown,
  icon,
  onClick,
  style
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 7,
      padding: '8px 14px',
      borderRadius: 'var(--radius-pill)',
      cursor: 'pointer',
      font: `var(--fw-medium) 13px/1 var(--font-sans)`,
      background: active ? 'var(--accent-soft)' : 'var(--surface)',
      color: active ? 'var(--accent)' : 'var(--ink-700)',
      border: `1px solid ${active ? 'transparent' : 'var(--hairline-strong)'}`,
      boxShadow: active ? 'none' : 'var(--shadow-xs)',
      transition: 'background var(--dur-fast) var(--ease-out)',
      whiteSpace: 'nowrap'
    },
    onMouseEnter: e => {
      if (!active) e.currentTarget.style.background = 'var(--surface-hover)';
    },
    onMouseLeave: e => {
      if (!active) e.currentTarget.style.background = 'var(--surface)';
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 15,
    strokeWidth: 2
  }), children, count != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: 'tabular-nums',
      fontWeight: 'var(--fw-semibold)',
      fontSize: 11,
      minWidth: 18,
      height: 18,
      padding: '0 5px',
      borderRadius: 'var(--radius-pill)',
      display: 'inline-grid',
      placeItems: 'center',
      background: active ? 'var(--accent)' : 'var(--surface-sunken)',
      color: active ? 'var(--accent-fg)' : 'var(--ink-500)'
    }
  }, count), dropdown && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 15,
    strokeWidth: 2,
    style: {
      marginRight: -2,
      opacity: .7
    }
  }));
}
Object.assign(__ds_scope, { FilterPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/FilterPill.jsx", error: String((e && e.message) || e) }); }

// components/controls/SearchField.jsx
try { (() => {
/** Search input with a leading magnifier and focus ring. Clears via the trailing ✕ when filled. */
function SearchField({
  value,
  onChange,
  placeholder = 'Suchen …',
  onClear,
  width,
  style
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 9,
      width: width || 320,
      padding: '10px 12px',
      borderRadius: 'var(--radius-md)',
      background: 'var(--surface)',
      border: `1px solid ${focus ? 'var(--accent)' : 'var(--hairline-strong)'}`,
      boxShadow: focus ? `0 0 0 3px var(--accent-ring)` : 'var(--shadow-xs)',
      transition: 'box-shadow var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "search",
    size: 17,
    color: "var(--ink-400)"
  }), /*#__PURE__*/React.createElement("input", {
    value: value,
    placeholder: placeholder,
    onChange: e => onChange && onChange(e.target.value),
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 'none',
      background: 'transparent',
      font: `var(--fw-regular) 14px/1 var(--font-sans)`,
      color: 'var(--ink-900)'
    }
  }), value && /*#__PURE__*/React.createElement("button", {
    onClick: onClear,
    "aria-label": "Leeren",
    style: {
      border: 0,
      background: 'transparent',
      cursor: 'pointer',
      display: 'grid',
      placeItems: 'center',
      color: 'var(--ink-400)',
      padding: 0
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 15,
    strokeWidth: 2.25
  })));
}
Object.assign(__ds_scope, { SearchField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/controls/SearchField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Sidebar.jsx
try { (() => {
const NAV = [{
  id: 'dashboard',
  label: 'Dashboard',
  icon: 'layout-dashboard'
}, {
  id: 'transaktionen',
  label: 'Transaktionen',
  icon: 'arrow-left-right'
}, {
  id: 'vertraege',
  label: 'Verträge',
  icon: 'repeat'
}, {
  id: 'analyse',
  label: 'Analyse',
  icon: 'pie-chart'
}, {
  id: 'einstellungen',
  label: 'Einstellungen',
  icon: 'settings'
}];
function NavItem({
  item,
  active,
  onClick
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    onClick: () => onClick && onClick(item.id),
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      width: '100%',
      textAlign: 'left',
      padding: '11px 12px',
      borderRadius: 'var(--radius-md)',
      border: 0,
      cursor: 'pointer',
      font: `${active ? 'var(--fw-semibold)' : 'var(--fw-medium)'} 14.5px/1 var(--font-sans)`,
      background: active ? 'var(--accent)' : hover ? 'var(--surface-hover)' : 'transparent',
      color: active ? 'var(--accent-fg)' : hover ? 'var(--ink-900)' : 'var(--ink-500)',
      boxShadow: active ? 'var(--shadow-accent)' : 'none',
      transition: 'background var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: item.icon,
    size: 19,
    strokeWidth: active ? 2 : 1.75
  }), item.label);
}

/** Desktop sidebar navigation. Active item = filled marine pill; hover lightens the row. */
function Sidebar({
  active = 'analyse',
  onNavigate,
  items = NAV,
  footer,
  style
}) {
  return /*#__PURE__*/React.createElement("aside", {
    style: {
      width: 'var(--sidebar-w)',
      flex: 'none',
      minHeight: '100%',
      display: 'flex',
      flexDirection: 'column',
      padding: '26px 16px 20px',
      background: 'var(--bg)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      padding: '0 12px 26px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      placeItems: 'center',
      width: 30,
      height: 30,
      borderRadius: 9,
      background: 'var(--accent)',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "wallet",
    size: 17,
    strokeWidth: 2
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--fw-bold) 19px/1 var(--font-display)`,
      letterSpacing: '-.015em',
      color: 'var(--ink-900)'
    }
  }, "Financiero")), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 4
    }
  }, items.map(it => /*#__PURE__*/React.createElement(NavItem, {
    key: it.id,
    item: it,
    active: it.id === active,
    onClick: onNavigate
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto'
    }
  }, footer));
}
Object.assign(__ds_scope, { Sidebar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Sidebar.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Badge.jsx
try { (() => {
const TONES = {
  neutral: {
    bg: 'var(--surface-sunken)',
    fg: 'var(--ink-500)'
  },
  accent: {
    bg: 'var(--accent-soft)',
    fg: 'var(--accent)'
  },
  income: {
    bg: 'var(--income-soft-bg)',
    fg: 'var(--income)'
  },
  expense: {
    bg: 'var(--expense-soft-bg)',
    fg: 'var(--expense-strong)'
  },
  review: {
    bg: 'var(--review-soft-bg)',
    fg: 'var(--review)'
  },
  uncat: {
    bg: 'var(--uncat-soft-bg)',
    fg: 'var(--uncat)'
  }
};

/** Small pill label for status/category. `tone` sets semantic colors; optional leading icon. */
function Badge({
  children,
  tone = 'neutral',
  icon,
  style
}) {
  const t = TONES[tone] || TONES.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      padding: icon ? '4px 10px 4px 8px' : '4px 10px',
      borderRadius: 'var(--radius-pill)',
      background: t.bg,
      color: t.fg,
      font: `var(--fw-semibold) var(--text-xs)/1 var(--font-sans)`,
      whiteSpace: 'nowrap',
      ...style
    }
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 13,
    strokeWidth: 2
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data/TransactionRow.jsx
try { (() => {
/**
 * Single transaction row: merchant avatar (initial), name + meta, optional category badge,
 * signed amount (green income / red expense, tabular right-aligned), recurring & review markers.
 */
function TransactionRow({
  name,
  meta,
  amount,
  direction,
  category,
  categoryTone = 'neutral',
  recurring,
  review,
  uncategorized,
  avatarColor,
  onClick,
  style
}) {
  const [hover, setHover] = React.useState(false);
  const initial = (name || '?').trim().charAt(0).toUpperCase();
  const isIncome = direction === 'income';
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 14,
      padding: '0 12px',
      height: 64,
      borderRadius: 'var(--radius-md)',
      cursor: onClick ? 'pointer' : 'default',
      background: hover ? 'var(--surface-hover)' : 'transparent',
      transition: 'background var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 38,
      height: 38,
      flex: 'none',
      borderRadius: 'var(--radius-sm)',
      display: 'grid',
      placeItems: 'center',
      background: avatarColor || 'var(--accent-soft)',
      color: avatarColor ? '#fff' : 'var(--accent)',
      font: `var(--fw-semibold) 14px/1 var(--font-sans)`
    }
  }, initial), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--fw-medium) var(--text-body)/1.2 var(--font-sans)`,
      color: 'var(--ink-900)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, name), recurring && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "repeat",
    size: 14,
    color: "var(--ink-400)",
    strokeWidth: 2
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginTop: 3
    }
  }, meta && /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--fw-regular) var(--text-xs)/1.2 var(--font-sans)`,
      color: 'var(--ink-400)'
    }
  }, meta))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, uncategorized ? /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "uncat"
  }, "Nicht kategorisiert") : category && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: categoryTone
  }, category), review && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "review",
    icon: "triangle-alert"
  }, "Pr\xFCfen"), /*#__PURE__*/React.createElement("span", {
    style: {
      minWidth: 104,
      textAlign: 'right',
      font: `var(--fw-semibold) 15px/1 var(--font-display)`,
      letterSpacing: '-.01em',
      fontVariantNumeric: 'tabular-nums',
      fontFeatureSettings: '"tnum" 1',
      color: isIncome ? 'var(--income)' : 'var(--ink-900)'
    }
  }, amount)));
}
Object.assign(__ds_scope, { TransactionRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/TransactionRow.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
/** White floating card — the base container. Soft diffuse shadow, radius-lg, optional title/action header. */
function Card({
  title,
  subtitle,
  action,
  children,
  pad = 'var(--card-pad)',
  style,
  bodyStyle
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-md)',
      border: '1px solid var(--hairline)',
      padding: pad,
      ...style
    }
  }, (title || action) && /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: 16,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", null, title && /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      font: `var(--fw-semibold) var(--text-title)/1.2 var(--font-sans)`,
      color: 'var(--ink-900)',
      letterSpacing: '-.01em'
    }
  }, title), subtitle && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '4px 0 0',
      font: `var(--fw-regular) var(--text-sm)/1.3 var(--font-sans)`,
      color: 'var(--ink-500)'
    }
  }, subtitle)), action), /*#__PURE__*/React.createElement("div", {
    style: bodyStyle
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/EmptyState.jsx
try { (() => {
/** Empty state: centered icon in a soft disc, title, message, optional action. For empty charts/lists. */
function EmptyState({
  icon = 'inbox',
  title,
  message,
  action,
  compact,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      padding: compact ? '28px 24px' : '48px 32px',
      gap: 4,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: compact ? 44 : 56,
      height: compact ? 44 : 56,
      borderRadius: 'var(--radius-lg)',
      display: 'grid',
      placeItems: 'center',
      background: 'var(--surface-sunken)',
      color: 'var(--ink-400)',
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: compact ? 22 : 26,
    strokeWidth: 1.75
  })), title && /*#__PURE__*/React.createElement("div", {
    style: {
      font: `var(--fw-semibold) var(--text-title)/1.3 var(--font-sans)`,
      color: 'var(--ink-900)'
    }
  }, title), message && /*#__PURE__*/React.createElement("div", {
    style: {
      font: `var(--fw-regular) var(--text-sm)/1.5 var(--font-sans)`,
      color: 'var(--ink-500)',
      maxWidth: 320
    }
  }, message), action && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, action));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/KpiCard.jsx
try { (() => {
const TONES = {
  neutral: {
    bg: 'var(--surface)',
    label: 'var(--ink-400)',
    value: 'var(--ink-900)',
    delta: 'var(--ink-500)',
    border: '1px solid var(--hairline)'
  },
  income: {
    bg: 'var(--income-soft-bg)',
    label: 'var(--income-mid)',
    value: 'var(--income)',
    delta: 'var(--income-mid)',
    border: '1px solid transparent'
  },
  expense: {
    bg: 'var(--expense-soft-bg)',
    label: 'var(--expense)',
    value: 'var(--expense-strong)',
    delta: 'var(--expense)',
    border: '1px solid transparent'
  },
  accent: {
    bg: 'var(--accent)',
    label: 'rgba(255,255,255,.75)',
    value: '#fff',
    delta: 'rgba(255,255,255,.85)',
    border: '1px solid transparent'
  }
};

/** KPI tile: uppercase eyebrow, big Space Grotesk tabular value, optional delta. Financiero's signature. */
function KpiCard({
  label,
  value,
  delta,
  deltaDir,
  icon,
  tone = 'neutral',
  style
}) {
  const t = TONES[tone] || TONES.neutral;
  const dirIcon = deltaDir === 'up' ? 'trending-up' : deltaDir === 'down' ? 'trending-down' : null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: t.bg,
      border: t.border,
      borderRadius: 'var(--radius-lg)',
      boxShadow: tone === 'neutral' ? 'var(--shadow-md)' : tone === 'accent' ? 'var(--shadow-accent)' : 'none',
      padding: '20px 22px',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      font: `var(--fw-semibold) var(--text-2xs)/1 var(--font-sans)`,
      letterSpacing: 'var(--tracking-label)',
      textTransform: 'uppercase',
      color: t.label
    }
  }, label), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 17,
    color: t.label
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12,
      font: `var(--fw-bold) var(--text-kpi)/1 var(--font-display)`,
      letterSpacing: 'var(--tracking-tight)',
      color: t.value,
      fontVariantNumeric: 'tabular-nums',
      fontFeatureSettings: '"tnum" 1'
    }
  }, value), delta && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      display: 'flex',
      alignItems: 'center',
      gap: 5,
      font: `var(--fw-medium) var(--text-sm)/1 var(--font-sans)`,
      color: t.delta,
      fontVariantNumeric: 'tabular-nums'
    }
  }, dirIcon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: dirIcon,
    size: 15,
    strokeWidth: 2
  }), delta));
}
Object.assign(__ds_scope, { KpiCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/KpiCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/financiero/Analyse.jsx
try { (() => {
// Analyse screen — period toggle, income/expense KPIs, category donut, 6-month bars, top merchants.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const {
    Card,
    KpiCard,
    DonutChart,
    BarChart,
    SegmentedControl,
    Icon
  } = NS;
  const F = window.FIN;
  function MerchantRow({
    m,
    i
  }) {
    const initial = m.name.charAt(0).toUpperCase();
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 13,
        padding: '12px 0',
        borderBottom: i < F.topMerchants.length - 1 ? '1px solid var(--hairline)' : 0
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 34,
        height: 34,
        borderRadius: 9,
        background: 'var(--accent-soft)',
        color: 'var(--accent)',
        display: 'grid',
        placeItems: 'center',
        font: 'var(--fw-semibold) 13px/1 var(--font-sans)',
        flex: 'none'
      }
    }, initial), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-medium) 14px/1.2 var(--font-sans)',
        color: 'var(--ink-900)'
      }
    }, m.name), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-regular) 12px/1.2 var(--font-sans)',
        color: 'var(--ink-400)'
      }
    }, m.count, " ", m.count === 1 ? 'Buchung' : 'Buchungen')), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-semibold) 14px/1 var(--font-display)',
        color: 'var(--ink-900)',
        fontVariantNumeric: 'tabular-nums'
      }
    }, F.fmtEUR(m.amount)));
  }
  function Analyse() {
    const [range, setRange] = React.useState('monat');
    const donut = F.catSpend.map(c => ({
      label: F.CAT[c.key].label,
      value: c.value,
      display: F.fmtEUR(c.value),
      color: F.CAT[c.key].color
    }));
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(window.PageHeader, {
      title: "Analyse",
      lead: "Wof\xFCr dein Geld draufgeht.",
      right: /*#__PURE__*/React.createElement(SegmentedControl, {
        value: range,
        onChange: setRange,
        options: [{
          value: 'monat',
          label: 'Monat'
        }, {
          value: '3m',
          label: '3 Monate'
        }, {
          value: 'jahr',
          label: '1 Jahr'
        }]
      })
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 18,
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement(KpiCard, {
      tone: "income",
      label: "Einnahmen",
      value: F.fmtEUR(F.kpis.einnahmen),
      delta: "4,2 % gg\xFC. Vormonat",
      deltaDir: "up"
    }), /*#__PURE__*/React.createElement(KpiCard, {
      tone: "expense",
      label: "Ausgaben",
      value: F.fmtEUR(F.kpis.ausgaben),
      delta: "7,3 % gg\xFC. Vormonat",
      deltaDir: "down"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: '1.35fr 1fr',
        gap: 18,
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Ausgaben nach Kategorie",
      subtitle: "Juli 2026"
    }, /*#__PURE__*/React.createElement(DonutChart, {
      size: 168,
      thickness: 24,
      centerValue: F.fmtEUR(F.kpis.ausgaben).replace(',43 €', ' €'),
      data: donut
    })), /*#__PURE__*/React.createElement(Card, {
      title: "Top-H\xE4ndler",
      subtitle: "Nach Ausgaben"
    }, F.topMerchants.map((m, i) => /*#__PURE__*/React.createElement(MerchantRow, {
      key: m.name,
      m: m,
      i: i
    })))), /*#__PURE__*/React.createElement(Card, {
      title: "Einnahmen vs. Ausgaben",
      subtitle: "Letzte 6 Monate"
    }, /*#__PURE__*/React.createElement(BarChart, {
      highlightLast: true,
      height: 168,
      series: [{
        name: 'Einnahmen',
        color: 'var(--income-mid)'
      }, {
        name: 'Ausgaben',
        color: 'var(--expense)'
      }],
      data: F.trend
    })));
  }
  window.Analyse = Analyse;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/financiero/Analyse.jsx", error: String((e && e.message) || e) }); }

// ui_kits/financiero/Dashboard.jsx
try { (() => {
// Dashboard screen.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const {
    Card,
    KpiCard,
    DonutChart,
    TransactionRow,
    Badge,
    Button,
    Icon
  } = NS;
  const F = window.FIN;
  function AccountRow({
    a
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 13,
        padding: '13px 0',
        borderBottom: '1px solid var(--hairline)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 36,
        height: 36,
        borderRadius: 10,
        background: a.color,
        color: '#fff',
        display: 'grid',
        placeItems: 'center',
        flex: 'none'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "landmark",
      size: 18,
      strokeWidth: 2
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-medium) 14px/1.2 var(--font-sans)',
        color: 'var(--ink-900)'
      }
    }, a.name), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-regular) 12px/1.2 var(--font-sans)',
        color: 'var(--ink-400)',
        fontVariantNumeric: 'tabular-nums'
      }
    }, a.iban)), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-semibold) 15px/1 var(--font-display)',
        color: 'var(--ink-900)',
        fontVariantNumeric: 'tabular-nums',
        letterSpacing: '-.01em'
      }
    }, F.fmtEUR(a.balance)));
  }
  function Upcoming({
    c
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 13,
        padding: '11px 0',
        borderBottom: '1px solid var(--hairline)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 34,
        height: 34,
        borderRadius: 9,
        background: 'var(--surface-sunken)',
        color: 'var(--ink-500)',
        display: 'grid',
        placeItems: 'center',
        flex: 'none'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "calendar",
      size: 16
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-medium) 13.5px/1.2 var(--font-sans)',
        color: 'var(--ink-900)'
      }
    }, c.merchant), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-regular) 11.5px/1.2 var(--font-sans)',
        color: 'var(--ink-400)'
      }
    }, c.next)), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-semibold) 14px/1 var(--font-display)',
        color: 'var(--ink-900)',
        fontVariantNumeric: 'tabular-nums'
      }
    }, F.fmtEUR(c.amount)));
  }
  function Dashboard() {
    const donut = F.catSpend.slice(0, 6).map(c => ({
      label: F.CAT[c.key].label,
      value: c.value,
      display: F.fmtEUR(c.value),
      color: F.CAT[c.key].color
    }));
    const recent = F.txns.slice(0, 5);
    const upcoming = F.contracts.filter(c => c.status === 'aktiv').slice(0, 4);
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(window.PageHeader, {
      title: "Dashboard",
      lead: "\xDCberblick \xFCber deine Finanzen.",
      right: /*#__PURE__*/React.createElement(Button, {
        icon: "refresh-cw"
      }, "Jetzt synchronisieren")
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(4,1fr)',
        gap: 18,
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement(KpiCard, {
      tone: "accent",
      label: "Gesamtsaldo",
      value: F.fmtEUR(F.kpis.saldo),
      icon: "wallet"
    }), /*#__PURE__*/React.createElement(KpiCard, {
      tone: "income",
      label: "Einnahmen / Monat",
      value: F.fmtEUR(F.kpis.einnahmen),
      delta: "4,2 % gg\xFC. Vormonat",
      deltaDir: "up"
    }), /*#__PURE__*/React.createElement(KpiCard, {
      tone: "expense",
      label: "Ausgaben / Monat",
      value: F.fmtEUR(F.kpis.ausgaben),
      delta: "7,3 % gg\xFC. Vormonat",
      deltaDir: "down"
    }), /*#__PURE__*/React.createElement(KpiCard, {
      tone: "neutral",
      label: "Abos / Monat",
      value: F.fmtEUR(F.kpis.abos),
      icon: "repeat"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: '1.3fr 1fr',
        gap: 18,
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Ausgaben nach Kategorie",
      subtitle: "Juli 2026"
    }, /*#__PURE__*/React.createElement(DonutChart, {
      size: 160,
      thickness: 22,
      centerValue: F.fmtEUR(2187.43).replace(',43 €', ' €'),
      data: donut
    })), /*#__PURE__*/React.createElement(Card, {
      title: "Konten",
      action: /*#__PURE__*/React.createElement(Button, {
        variant: "ghost",
        size: "sm",
        iconRight: "chevron-right"
      }, "Alle")
    }, F.accounts.map(a => /*#__PURE__*/React.createElement(AccountRow, {
      key: a.id,
      a: a
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: '1.3fr 1fr',
        gap: 18
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Letzte Ums\xE4tze",
      action: /*#__PURE__*/React.createElement(Button, {
        variant: "ghost",
        size: "sm",
        iconRight: "chevron-right"
      }, "Alle Ums\xE4tze"),
      bodyStyle: {
        margin: '0 -12px'
      }
    }, recent.map(t => /*#__PURE__*/React.createElement(TransactionRow, {
      key: t.id,
      name: t.name,
      meta: `${t.acct} · ${F.shortDate(t.date)}`,
      amount: F.fmtEUR(t.amount),
      direction: t.amount > 0 ? 'income' : 'expense',
      category: t.cat ? F.CAT[t.cat].label : null,
      categoryTone: t.cat === 'einkommen' ? 'income' : 'neutral',
      uncategorized: !t.cat,
      review: t.review,
      recurring: t.recurring
    }))), /*#__PURE__*/React.createElement(Card, {
      title: "Anstehende Abbuchungen",
      subtitle: "N\xE4chste 14 Tage"
    }, upcoming.map(c => /*#__PURE__*/React.createElement(Upcoming, {
      key: c.id,
      c: c
    })))));
  }
  window.Dashboard = Dashboard;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/financiero/Dashboard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/financiero/Einstellungen.jsx
try { (() => {
// Einstellungen screen — Bankverbindungen, CSV-Import, Review-Queue.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const {
    Card,
    Badge,
    Button,
    Icon,
    TransactionRow
  } = NS;
  const F = window.FIN;
  function BankRow({
    a,
    i
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 13,
        padding: '14px 0',
        borderBottom: i < F.accounts.length - 1 ? '1px solid var(--hairline)' : 0
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 38,
        height: 38,
        borderRadius: 10,
        background: a.color,
        color: '#fff',
        display: 'grid',
        placeItems: 'center',
        flex: 'none'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "landmark",
      size: 18,
      strokeWidth: 2
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-medium) 14px/1.2 var(--font-sans)',
        color: 'var(--ink-900)'
      }
    }, a.name), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-regular) 12px/1.2 var(--font-sans)',
        color: 'var(--ink-400)',
        fontVariantNumeric: 'tabular-nums'
      }
    }, a.iban)), /*#__PURE__*/React.createElement(Badge, {
      tone: "income",
      icon: "circle-check"
    }, "Verbunden"), /*#__PURE__*/React.createElement("button", {
      style: {
        ...window.iconBtn,
        width: 34,
        height: 34
      },
      title: "Optionen"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "ellipsis",
      size: 18
    })));
  }
  function ReviewRow({
    r,
    i
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 13,
        padding: '13px 0',
        borderBottom: i < F.reviewQueue.length - 1 ? '1px solid var(--hairline)' : 0
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 36,
        height: 36,
        borderRadius: 9,
        background: 'var(--review-soft-bg)',
        color: 'var(--review)',
        display: 'grid',
        placeItems: 'center',
        flex: 'none'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "triangle-alert",
      size: 17,
      strokeWidth: 2
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-medium) 14px/1.2 var(--font-sans)',
        color: 'var(--ink-900)'
      }
    }, r.name), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-regular) 12px/1.2 var(--font-sans)',
        color: 'var(--ink-400)'
      }
    }, "Vorschlag: ", r.guess, " \xB7 ", r.acct)), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-semibold) 14px/1 var(--font-display)',
        color: 'var(--ink-900)',
        fontVariantNumeric: 'tabular-nums',
        marginRight: 4
      }
    }, F.fmtEUR(r.amount)), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary"
    }, "\xDCbernehmen"));
  }
  function Einstellungen() {
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(window.PageHeader, {
      title: "Einstellungen",
      lead: "Konten, Datenimport und Kategorisierung."
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 18,
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement(Card, {
      title: "Bankverbindungen",
      action: /*#__PURE__*/React.createElement(Button, {
        size: "sm",
        icon: "plus"
      }, "Konto hinzuf\xFCgen")
    }, F.accounts.map((a, i) => /*#__PURE__*/React.createElement(BankRow, {
      key: a.id,
      a: a,
      i: i
    }))), /*#__PURE__*/React.createElement(Card, {
      title: "CSV-Import",
      subtitle: "Ums\xE4tze aus einer Datei einlesen"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        border: '1.5px dashed var(--hairline-strong)',
        borderRadius: 'var(--radius-md)',
        padding: '30px 20px',
        textAlign: 'center',
        background: 'var(--surface-raised)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-grid',
        placeItems: 'center',
        width: 46,
        height: 46,
        borderRadius: 12,
        background: 'var(--accent-soft)',
        color: 'var(--accent)',
        marginBottom: 12
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "upload",
      size: 22
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-medium) 14px/1.4 var(--font-sans)',
        color: 'var(--ink-900)'
      }
    }, "CSV hierher ziehen oder ausw\xE4hlen"), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-regular) 12.5px/1.4 var(--font-sans)',
        color: 'var(--ink-400)',
        margin: '4px 0 16px'
      }
    }, "DKB, N26, Sparkasse und weitere Formate"), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      icon: "file-text"
    }, "Datei ausw\xE4hlen")))), /*#__PURE__*/React.createElement(Card, {
      title: "Review-Queue",
      subtitle: "Von der KI unsicher kategorisiert",
      action: /*#__PURE__*/React.createElement(Badge, {
        tone: "review"
      }, F.reviewQueue.length, " offen")
    }, F.reviewQueue.map((r, i) => /*#__PURE__*/React.createElement(ReviewRow, {
      key: r.id,
      r: r,
      i: i
    }))));
  }
  window.Einstellungen = Einstellungen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/financiero/Einstellungen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/financiero/Mobile.jsx
try { (() => {
// Mobile screens — Dashboard & Transaktionen with bottom tab bar.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const {
    KpiCard,
    DonutChart,
    TransactionRow,
    SearchField,
    FilterPill,
    FilterChip,
    Badge,
    Icon
  } = NS;
  const F = window.FIN;
  const scroll = {
    flex: 1,
    overflowY: 'auto',
    padding: '52px 16px 16px'
  };
  const cardBox = {
    background: 'var(--surface)',
    border: '1px solid var(--hairline)',
    borderRadius: 'var(--radius-lg)',
    boxShadow: 'var(--shadow-sm)',
    padding: 16,
    marginBottom: 14
  };
  const cardTitle = {
    font: 'var(--fw-semibold) 14px/1 var(--font-sans)',
    color: 'var(--ink-900)',
    marginBottom: 14
  };
  function MobileHeader({
    title,
    sub
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 16
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-bold) 24px/1.1 var(--font-display)',
        letterSpacing: '-.02em',
        color: 'var(--ink-900)'
      }
    }, title), sub && /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-regular) 13px/1.3 var(--font-sans)',
        color: 'var(--ink-500)',
        marginTop: 4
      }
    }, sub));
  }
  function MobileDashboard({
    nav,
    onNav
  }) {
    const donut = F.catSpend.slice(0, 5).map(c => ({
      label: F.CAT[c.key].label,
      value: c.value,
      display: F.fmtEUR(c.value),
      color: F.CAT[c.key].color
    }));
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: scroll
    }, /*#__PURE__*/React.createElement(MobileHeader, {
      title: "Hallo, Jonas",
      sub: "\xDCberblick \xFCber deine Finanzen."
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--accent)',
        borderRadius: 'var(--radius-lg)',
        boxShadow: 'var(--shadow-accent)',
        padding: '18px 20px',
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-semibold) 10.5px/1 var(--font-sans)',
        letterSpacing: '.09em',
        textTransform: 'uppercase',
        color: 'rgba(255,255,255,.72)'
      }
    }, "Gesamtsaldo"), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-bold) 34px/1 var(--font-display)',
        letterSpacing: '-.02em',
        color: '#fff',
        marginTop: 10,
        fontVariantNumeric: 'tabular-nums'
      }
    }, F.fmtEUR(F.kpis.saldo))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 12,
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement(KpiCard, {
      tone: "income",
      label: "Einnahmen",
      value: F.fmtEUR(F.kpis.einnahmen)
    }), /*#__PURE__*/React.createElement(KpiCard, {
      tone: "expense",
      label: "Ausgaben",
      value: F.fmtEUR(F.kpis.ausgaben)
    })), /*#__PURE__*/React.createElement("div", {
      style: cardBox
    }, /*#__PURE__*/React.createElement("div", {
      style: cardTitle
    }, "Ausgaben nach Kategorie"), /*#__PURE__*/React.createElement(DonutChart, {
      size: 130,
      thickness: 20,
      centerValue: F.fmtEUR(F.kpis.ausgaben).replace(',43 €', ' €'),
      data: donut
    })), /*#__PURE__*/React.createElement("div", {
      style: cardBox
    }, /*#__PURE__*/React.createElement("div", {
      style: cardTitle
    }, "Letzte Ums\xE4tze"), /*#__PURE__*/React.createElement("div", {
      style: {
        margin: '0 -8px'
      }
    }, F.txns.slice(0, 4).map(t => /*#__PURE__*/React.createElement(TransactionRow, {
      key: t.id,
      name: t.name,
      meta: F.shortDate(t.date),
      amount: F.fmtEUR(t.amount),
      direction: t.amount > 0 ? 'income' : 'expense',
      recurring: t.recurring
    }))))), /*#__PURE__*/React.createElement(window.MobileTabBar, {
      active: nav,
      onNavigate: onNav
    }));
  }
  function MobileTransaktionen({
    nav,
    onNav
  }) {
    const [q, setQ] = React.useState('');
    const filtered = F.txns.filter(t => !q || t.name.toLowerCase().includes(q.toLowerCase()));
    const groups = F.groupByDate(filtered);
    return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
      style: scroll
    }, /*#__PURE__*/React.createElement(MobileHeader, {
      title: "Ums\xE4tze"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        marginBottom: 12
      }
    }, /*#__PURE__*/React.createElement(SearchField, {
      value: q,
      onChange: setQ,
      onClear: () => setQ(''),
      placeholder: "Suchen \u2026",
      width: '100%',
      style: {
        width: '100%'
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8,
        marginBottom: 12,
        overflowX: 'auto',
        paddingBottom: 2
      }
    }, /*#__PURE__*/React.createElement(FilterPill, {
      active: true,
      count: filtered.length
    }, "Alle"), /*#__PURE__*/React.createElement(FilterPill, {
      dropdown: true
    }, "Kategorie"), /*#__PURE__*/React.createElement(FilterPill, {
      dropdown: true
    }, "Konto")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 6,
        marginBottom: 14
      }
    }, /*#__PURE__*/React.createElement(FilterChip, {
      label: "Konto",
      value: "DKB Girokonto",
      onRemove: () => {}
    })), groups.map(g => /*#__PURE__*/React.createElement("div", {
      key: g.label,
      style: cardBox
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'baseline',
        marginBottom: 6
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-semibold) 11px/1 var(--font-sans)',
        letterSpacing: '.04em',
        textTransform: 'uppercase',
        color: 'var(--ink-400)'
      }
    }, g.label), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-medium) 12px/1 var(--font-display)',
        color: 'var(--ink-500)',
        fontVariantNumeric: 'tabular-nums'
      }
    }, F.fmtEUR(g.sum))), /*#__PURE__*/React.createElement("div", {
      style: {
        margin: '0 -8px'
      }
    }, g.items.map(t => /*#__PURE__*/React.createElement(TransactionRow, {
      key: t.id,
      name: t.name,
      meta: t.acct,
      amount: F.fmtEUR(t.amount),
      direction: t.amount > 0 ? 'income' : 'expense',
      uncategorized: !t.cat,
      review: t.review,
      recurring: t.recurring
    })))))), /*#__PURE__*/React.createElement(window.MobileTabBar, {
      active: nav,
      onNavigate: onNav
    }));
  }
  Object.assign(window, {
    MobileDashboard,
    MobileTransaktionen
  });
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/financiero/Mobile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/financiero/Shell.jsx
try { (() => {
// Financiero UI kit — shell chrome (topbar, page header, sidebar footer, mobile tab bar).
const {
  Icon,
  Button
} = window.FinancieroDesignSystem_854562;

// Top bar: page context left, search-hint + sync + account right.
function Topbar({
  title
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 42px',
      height: 72,
      borderBottom: '1px solid var(--hairline)',
      background: 'var(--bg)',
      position: 'sticky',
      top: 0,
      zIndex: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--fw-semibold) 15px/1 var(--font-sans)',
      color: 'var(--ink-500)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: iconBtn,
    title: "Benachrichtigungen"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 19
  })), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    icon: "refresh-cw"
  }, "Synchronisieren"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9,
      paddingLeft: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 10,
      background: 'var(--accent-soft)',
      color: 'var(--accent)',
      display: 'grid',
      placeItems: 'center',
      font: 'var(--fw-semibold) 13px/1 var(--font-sans)'
    }
  }, "JM"))));
}
const iconBtn = {
  display: 'grid',
  placeItems: 'center',
  width: 38,
  height: 38,
  borderRadius: 'var(--radius-md)',
  border: '1px solid var(--hairline-strong)',
  background: 'var(--surface)',
  color: 'var(--ink-500)',
  cursor: 'pointer',
  boxShadow: 'var(--shadow-xs)'
};

// Page header: big h1 + optional lead + right slot (segmented / actions).
function PageHeader({
  title,
  lead,
  right,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 20,
      marginBottom: 26,
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      font: 'var(--fw-bold) var(--text-h1)/1.1 var(--font-display)',
      letterSpacing: 'var(--tracking-tight)',
      color: 'var(--ink-900)'
    }
  }, title), lead && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '7px 0 0',
      font: 'var(--fw-regular) 14.5px/1.4 var(--font-sans)',
      color: 'var(--ink-500)'
    }
  }, lead)), right);
}

// Sidebar footer — account chip + sign out.
function AccountFooter() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--hairline)',
      paddingTop: 14,
      marginTop: 14,
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 34,
      height: 34,
      borderRadius: 10,
      background: 'var(--accent-soft)',
      color: 'var(--accent)',
      display: 'grid',
      placeItems: 'center',
      font: 'var(--fw-semibold) 13px/1 var(--font-sans)',
      flex: 'none'
    }
  }, "JM"), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--fw-semibold) 13px/1.2 var(--font-sans)',
      color: 'var(--ink-900)'
    }
  }, "Jonas M\xFCller"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: 'var(--fw-regular) 11.5px/1.2 var(--font-sans)',
      color: 'var(--ink-400)'
    }
  }, "jonas@example.de")), /*#__PURE__*/React.createElement("button", {
    style: {
      ...iconBtn,
      width: 32,
      height: 32,
      border: 0,
      background: 'transparent',
      boxShadow: 'none'
    },
    title: "Abmelden"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "log-out",
    size: 17
  })));
}

// Mobile bottom tab bar.
const MOBILE_TABS = [{
  id: 'dashboard',
  label: 'Start',
  icon: 'layout-dashboard'
}, {
  id: 'transaktionen',
  label: 'Umsätze',
  icon: 'arrow-left-right'
}, {
  id: 'analyse',
  label: 'Analyse',
  icon: 'pie-chart'
}, {
  id: 'vertraege',
  label: 'Verträge',
  icon: 'repeat'
}];
function MobileTabBar({
  active,
  onNavigate
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      justifyContent: 'space-around',
      alignItems: 'stretch',
      borderTop: '1px solid var(--hairline)',
      background: 'var(--surface)',
      paddingBottom: 18,
      paddingTop: 8
    }
  }, MOBILE_TABS.map(t => {
    const on = t.id === active;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      onClick: () => onNavigate && onNavigate(t.id),
      style: {
        flex: 1,
        border: 0,
        background: 'transparent',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 4,
        color: on ? 'var(--accent)' : 'var(--ink-400)',
        padding: '4px 0'
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: t.icon,
      size: 22,
      strokeWidth: on ? 2.2 : 1.75
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        font: `${on ? 'var(--fw-semibold)' : 'var(--fw-medium)'} 10.5px/1 var(--font-sans)`
      }
    }, t.label));
  }));
}

// Phone frame for mobile screens.
function PhoneFrame({
  children,
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 390,
      height: 800,
      borderRadius: 44,
      background: '#0d0f13',
      padding: 11,
      boxShadow: 'var(--shadow-lg)',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      height: '100%',
      borderRadius: 34,
      overflow: 'hidden',
      background: 'var(--bg)',
      position: 'relative',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 9,
      left: '50%',
      transform: 'translateX(-50%)',
      width: 120,
      height: 30,
      borderRadius: 999,
      background: '#0d0f13',
      zIndex: 20
    }
  }), children)), label && /*#__PURE__*/React.createElement("span", {
    style: {
      font: 'var(--fw-medium) 13px/1 var(--font-sans)',
      color: 'var(--ink-400)'
    }
  }, label));
}
Object.assign(window, {
  Topbar,
  PageHeader,
  AccountFooter,
  MobileTabBar,
  PhoneFrame,
  iconBtn
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/financiero/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/financiero/Transaktionen.jsx
try { (() => {
// Transaktionen screen — search, filters, active chips, date groups, sum row.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const {
    Card,
    TransactionRow,
    SearchField,
    FilterPill,
    FilterChip,
    SegmentedControl,
    Button
  } = NS;
  const F = window.FIN;
  function Transaktionen() {
    const [q, setQ] = React.useState('');
    const [chips, setChips] = React.useState([{
      id: 'konto',
      label: 'Konto',
      value: 'DKB Girokonto'
    }, {
      id: 'zeit',
      label: 'Zeitraum',
      value: 'Juli 2026'
    }]);
    const remove = id => setChips(c => c.filter(x => x.id !== id));
    const filtered = F.txns.filter(t => !q || t.name.toLowerCase().includes(q.toLowerCase()));
    const groups = F.groupByDate(filtered);
    const total = filtered.reduce((s, t) => s + t.amount, 0);
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(window.PageHeader, {
      title: "Transaktionen",
      lead: `${filtered.length} Umsätze · ${F.fmtEUR(total)}`,
      right: /*#__PURE__*/React.createElement(Button, {
        variant: "secondary",
        icon: "upload"
      }, "CSV importieren")
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        marginBottom: 14,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement(SearchField, {
      value: q,
      onChange: setQ,
      onClear: () => setQ(''),
      placeholder: "Ums\xE4tze durchsuchen \u2026",
      width: 340
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }), /*#__PURE__*/React.createElement(FilterPill, {
      icon: "sliders-horizontal"
    }, "Filter"), /*#__PURE__*/React.createElement(FilterPill, {
      dropdown: true
    }, "Kategorie"), /*#__PURE__*/React.createElement(FilterPill, {
      dropdown: true
    }, "Konto"), /*#__PURE__*/React.createElement(SegmentedControl, {
      value: "alle",
      onChange: () => {},
      size: "sm",
      options: [{
        value: 'alle',
        label: 'Alle'
      }, {
        value: 'aus',
        label: 'Ausgaben'
      }, {
        value: 'ein',
        label: 'Einnahmen'
      }]
    })), chips.length > 0 && /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        marginBottom: 16,
        flexWrap: 'wrap'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-medium) 12px/1 var(--font-sans)',
        color: 'var(--ink-400)'
      }
    }, "Aktive Filter:"), chips.map(c => /*#__PURE__*/React.createElement(FilterChip, {
      key: c.id,
      label: c.label,
      value: c.value,
      onRemove: () => remove(c.id)
    })), /*#__PURE__*/React.createElement("button", {
      onClick: () => setChips([]),
      style: {
        border: 0,
        background: 'transparent',
        cursor: 'pointer',
        font: 'var(--fw-medium) 12px/1 var(--font-sans)',
        color: 'var(--accent)',
        padding: '6px 4px'
      }
    }, "Alle zur\xFCcksetzen")), /*#__PURE__*/React.createElement(Card, {
      style: {
        padding: '8px 12px'
      },
      bodyStyle: {}
    }, groups.length === 0 && /*#__PURE__*/React.createElement(NS.EmptyState, {
      icon: "search",
      title: "Keine Treffer",
      message: `Für „${q}" wurden keine Umsätze gefunden.`
    }), groups.map(g => /*#__PURE__*/React.createElement("div", {
      key: g.label
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'baseline',
        justifyContent: 'space-between',
        padding: '16px 12px 6px'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-semibold) 12px/1 var(--font-sans)',
        letterSpacing: '.04em',
        textTransform: 'uppercase',
        color: 'var(--ink-400)'
      }
    }, g.label), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-medium) 12.5px/1 var(--font-display)',
        color: 'var(--ink-500)',
        fontVariantNumeric: 'tabular-nums'
      }
    }, F.fmtEUR(g.sum))), g.items.map(t => /*#__PURE__*/React.createElement(TransactionRow, {
      key: t.id,
      name: t.name,
      meta: `${t.acct} · ${F.shortDate(t.date)}`,
      amount: F.fmtEUR(t.amount),
      direction: t.amount > 0 ? 'income' : 'expense',
      category: t.cat ? F.CAT[t.cat].label : null,
      categoryTone: t.cat === 'einkommen' ? 'income' : 'neutral',
      uncategorized: !t.cat,
      review: t.review,
      recurring: t.recurring
    }))))));
  }
  window.Transaktionen = Transaktionen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/financiero/Transaktionen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/financiero/Vertraege.jsx
try { (() => {
// Verträge screen — summary card, status segmented, contract cards. (Airier layout.)
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const {
    Card,
    KpiCard,
    SegmentedControl,
    Badge,
    Icon,
    Button
  } = NS;
  const F = window.FIN;
  function ContractCard({
    c
  }) {
    const income = c.amount > 0;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 18,
        padding: '24px 26px',
        background: 'var(--surface)',
        border: '1px solid var(--hairline)',
        borderRadius: 'var(--radius-lg)',
        boxShadow: 'var(--shadow-md)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 50,
        height: 50,
        borderRadius: 13,
        background: income ? 'var(--income-soft-bg)' : 'var(--accent-soft)',
        color: income ? 'var(--income)' : 'var(--accent)',
        display: 'grid',
        placeItems: 'center',
        font: 'var(--fw-semibold) 17px/1 var(--font-sans)',
        flex: 'none'
      }
    }, c.merchant.charAt(0)), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 9
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-semibold) 16px/1.2 var(--font-sans)',
        color: 'var(--ink-900)'
      }
    }, c.merchant), /*#__PURE__*/React.createElement(Badge, {
      tone: "neutral",
      icon: "repeat"
    }, c.cycle)), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-regular) 13.5px/1.3 var(--font-sans)',
        color: 'var(--ink-500)',
        marginTop: 6
      }
    }, c.name, " \xB7 n\xE4chste Buchung am ", c.next)), /*#__PURE__*/React.createElement("div", {
      style: {
        textAlign: 'right'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-bold) 20px/1 var(--font-display)',
        color: income ? 'var(--income)' : 'var(--ink-900)',
        fontVariantNumeric: 'tabular-nums',
        letterSpacing: '-.01em'
      }
    }, F.fmtEUR(c.amount)), /*#__PURE__*/React.createElement("div", {
      style: {
        font: 'var(--fw-medium) 12px/1 var(--font-sans)',
        color: 'var(--ink-400)',
        marginTop: 7
      }
    }, "pro Monat")), /*#__PURE__*/React.createElement("button", {
      style: {
        ...window.iconBtn,
        width: 40,
        height: 40,
        marginLeft: 4
      },
      title: "Optionen"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "ellipsis",
      size: 18
    })));
  }
  function Vertraege() {
    const [tab, setTab] = React.useState('aktiv');
    const list = F.contracts.filter(c => c.status === tab);
    const monthly = F.contracts.filter(c => c.status === 'aktiv').reduce((s, c) => s + c.amount, 0);
    const activeCount = F.contracts.filter(c => c.status === 'aktiv').length;
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(window.PageHeader, {
      title: "Vertr\xE4ge",
      lead: "Wiederkehrende Buchungen und Abos im \xDCberblick.",
      style: {
        marginBottom: 32
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'grid',
        gridTemplateColumns: 'repeat(3,1fr)',
        gap: 20,
        marginBottom: 36
      }
    }, /*#__PURE__*/React.createElement(KpiCard, {
      tone: "neutral",
      label: "Fixkosten / Monat",
      value: F.fmtEUR(monthly),
      icon: "repeat"
    }), /*#__PURE__*/React.createElement(KpiCard, {
      tone: "neutral",
      label: "Aktive Vertr\xE4ge",
      value: String(activeCount),
      icon: "credit-card"
    }), /*#__PURE__*/React.createElement(KpiCard, {
      tone: "income",
      label: "Einnahmen / Monat",
      value: F.fmtEUR(F.kpis.einnahmen),
      icon: "trending-up"
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        marginBottom: 24
      }
    }, /*#__PURE__*/React.createElement(SegmentedControl, {
      value: tab,
      onChange: setTab,
      options: [{
        value: 'aktiv',
        label: 'Aktiv'
      }, {
        value: 'einnahme',
        label: 'Einnahmen'
      }, {
        value: 'beendet',
        label: 'Beendet'
      }]
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        font: 'var(--fw-medium) 13px/1 var(--font-sans)',
        color: 'var(--ink-400)'
      }
    }, list.length, " ", list.length === 1 ? 'Vertrag' : 'Verträge')), list.length === 0 ? /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(NS.EmptyState, {
      icon: "repeat",
      title: "Nichts hier",
      message: "Keine Vertr\xE4ge in dieser Ansicht."
    })) : /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 16
      }
    }, list.map(c => /*#__PURE__*/React.createElement(ContractCard, {
      key: c.id,
      c: c
    }))));
  }
  window.Vertraege = Vertraege;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/financiero/Vertraege.jsx", error: String((e && e.message) || e) }); }

// ui_kits/financiero/app.jsx
try { (() => {
// App — wires sidebar nav to desktop screens, plus a mobile preview panel.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const {
    Sidebar
  } = NS;
  const SCREENS = {
    dashboard: window.Dashboard,
    transaktionen: window.Transaktionen,
    vertraege: window.Vertraege,
    analyse: window.Analyse,
    einstellungen: window.Einstellungen
  };
  const TITLES = {
    dashboard: 'Dashboard',
    transaktionen: 'Transaktionen',
    vertraege: 'Verträge',
    analyse: 'Analyse',
    einstellungen: 'Einstellungen'
  };
  function App() {
    const [page, setPage] = React.useState('dashboard');
    const [mobilePage, setMobilePage] = React.useState('dashboard');
    const Screen = SCREENS[page] || window.Dashboard;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 40
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 1440,
        margin: '0 auto',
        background: 'var(--bg)',
        borderRadius: 'var(--radius-xl)',
        overflow: 'hidden',
        boxShadow: 'var(--shadow-lg)',
        display: 'flex',
        minHeight: 940
      }
    }, /*#__PURE__*/React.createElement(Sidebar, {
      active: page,
      onNavigate: setPage,
      footer: /*#__PURE__*/React.createElement(window.AccountFooter, null),
      style: {
        borderRight: '1px solid var(--hairline)'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0,
        display: 'flex',
        flexDirection: 'column'
      }
    }, /*#__PURE__*/React.createElement(window.Topbar, {
      title: TITLES[page]
    }), /*#__PURE__*/React.createElement("main", {
      style: {
        flex: 1,
        padding: '32px 42px 56px',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement(Screen, null)))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 44,
        justifyContent: 'center',
        flexWrap: 'wrap',
        paddingBottom: 20
      }
    }, /*#__PURE__*/React.createElement(window.PhoneFrame, {
      label: "Mobile \xB7 Dashboard"
    }, /*#__PURE__*/React.createElement(window.MobileDashboard, {
      nav: mobilePage,
      onNav: setMobilePage
    })), /*#__PURE__*/React.createElement(window.PhoneFrame, {
      label: "Mobile \xB7 Transaktionen"
    }, /*#__PURE__*/React.createElement(window.MobileTransaktionen, {
      nav: "transaktionen",
      onNav: () => {}
    }))));
  }
  window.FinApp = App;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/financiero/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/financiero/data.js
try { (() => {
// Financiero — realistic German sample data (no lorem). Attached to window.FIN.
(function () {
  const CAT = {
    wohnen: {
      label: 'Wohnen',
      color: 'var(--chart-1)'
    },
    lebensmittel: {
      label: 'Lebensmittel',
      color: 'var(--chart-2)'
    },
    mobilitaet: {
      label: 'Mobilität',
      color: 'var(--chart-3)'
    },
    freizeit: {
      label: 'Freizeit',
      color: 'var(--chart-4)'
    },
    versicherung: {
      label: 'Versicherung',
      color: 'var(--chart-5)'
    },
    abos: {
      label: 'Abos',
      color: 'var(--chart-6)'
    },
    gesundheit: {
      label: 'Gesundheit',
      color: 'var(--chart-7)'
    },
    einkommen: {
      label: 'Einkommen',
      color: 'var(--income-mid)'
    }
  };

  // Signed euro → "1.043,72 €" / "−9,99 €" / "+3.240,00 €"
  function fmtEUR(n, {
    sign = false
  } = {}) {
    const neg = n < 0;
    const s = Math.abs(n).toLocaleString('de-DE', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    const pre = neg ? '−' : sign ? '+' : '';
    return pre + s + ' €';
  }
  const accounts = [{
    id: 'dkb-giro',
    name: 'DKB Girokonto',
    iban: 'DE89 1203 0000 0009 4372',
    balance: 1043.72,
    bank: 'DKB',
    color: 'var(--chart-1)'
  }, {
    id: 'dkb-tg',
    name: 'DKB Tagesgeld',
    iban: 'DE21 1203 0000 0088 1200',
    balance: 12500.00,
    bank: 'DKB',
    color: 'var(--chart-6)'
  }, {
    id: 'n26',
    name: 'N26 Hauptkonto',
    iban: 'DE10 1001 1001 2620 8155',
    balance: 328.55,
    bank: 'N26',
    color: 'var(--ink-700)'
  }];

  // txns: amount signed; cat key; recurring/review/uncat flags
  const txns = [{
    id: 1,
    date: '2026-07-14',
    name: 'REWE',
    acct: 'DKB Girokonto',
    amount: -63.44,
    cat: 'lebensmittel'
  }, {
    id: 2,
    date: '2026-07-14',
    name: 'PayPal ·88213',
    acct: 'DKB Girokonto',
    amount: -42.10,
    cat: null,
    review: true
  }, {
    id: 3,
    date: '2026-07-12',
    name: 'DB Fernverkehr',
    acct: 'DKB Girokonto',
    amount: -49.90,
    cat: 'mobilitaet'
  }, {
    id: 4,
    date: '2026-07-10',
    name: 'dm-drogerie markt',
    acct: 'DKB Girokonto',
    amount: -21.35,
    cat: 'gesundheit'
  }, {
    id: 5,
    date: '2026-07-08',
    name: 'Allianz Versicherung',
    acct: 'DKB Girokonto',
    amount: -12.50,
    cat: 'versicherung',
    recurring: true
  }, {
    id: 6,
    date: '2026-07-05',
    name: 'Amazon',
    acct: 'N26 Hauptkonto',
    amount: -34.99,
    cat: null
  }, {
    id: 7,
    date: '2026-07-03',
    name: 'Testflix',
    acct: 'DKB Girokonto',
    amount: -9.99,
    cat: 'abos',
    recurring: true
  }, {
    id: 8,
    date: '2026-07-03',
    name: 'Spotify',
    acct: 'DKB Girokonto',
    amount: -10.99,
    cat: 'abos',
    recurring: true
  }, {
    id: 9,
    date: '2026-07-02',
    name: 'REWE',
    acct: 'DKB Girokonto',
    amount: -38.72,
    cat: 'lebensmittel'
  }, {
    id: 10,
    date: '2026-07-01',
    name: 'Miete Vermieter Weber',
    acct: 'DKB Girokonto',
    amount: -890.00,
    cat: 'wohnen',
    recurring: true
  }, {
    id: 11,
    date: '2026-07-01',
    name: 'Stadtwerke München',
    acct: 'DKB Girokonto',
    amount: -84.00,
    cat: 'wohnen',
    recurring: true
  }, {
    id: 12,
    date: '2026-06-30',
    name: 'Gehalt Muster GmbH',
    acct: 'DKB Girokonto',
    amount: 3240.00,
    cat: 'einkommen',
    recurring: true
  }, {
    id: 13,
    date: '2026-06-29',
    name: 'McFit',
    acct: 'N26 Hauptkonto',
    amount: -24.90,
    cat: 'gesundheit',
    recurring: true
  }, {
    id: 14,
    date: '2026-06-28',
    name: 'Shell Tankstelle',
    acct: 'DKB Girokonto',
    amount: -71.20,
    cat: 'mobilitaet'
  }, {
    id: 15,
    date: '2026-06-27',
    name: 'Vodafone',
    acct: 'DKB Girokonto',
    amount: -39.99,
    cat: 'abos',
    recurring: true
  }];

  // Contracts / recurring
  const contracts = [{
    id: 'miete',
    name: 'Miete',
    merchant: 'Vermieter Weber',
    amount: -890.00,
    cycle: 'Monatlich',
    cat: 'wohnen',
    next: '01.08.2026',
    status: 'aktiv'
  }, {
    id: 'gehalt',
    name: 'Gehalt',
    merchant: 'Muster GmbH',
    amount: 3240.00,
    cycle: 'Monatlich',
    cat: 'einkommen',
    next: '30.07.2026',
    status: 'einnahme'
  }, {
    id: 'vodafone',
    name: 'Mobilfunk',
    merchant: 'Vodafone',
    amount: -39.99,
    cycle: 'Monatlich',
    cat: 'abos',
    next: '27.07.2026',
    status: 'aktiv'
  }, {
    id: 'mcfit',
    name: 'Fitnessstudio',
    merchant: 'McFit',
    amount: -24.90,
    cycle: 'Monatlich',
    cat: 'gesundheit',
    next: '29.07.2026',
    status: 'aktiv'
  }, {
    id: 'allianz',
    name: 'Hausratversicherung',
    merchant: 'Allianz',
    amount: -12.50,
    cycle: 'Monatlich',
    cat: 'versicherung',
    next: '08.08.2026',
    status: 'aktiv'
  }, {
    id: 'spotify',
    name: 'Musik-Streaming',
    merchant: 'Spotify',
    amount: -10.99,
    cycle: 'Monatlich',
    cat: 'abos',
    next: '03.08.2026',
    status: 'aktiv'
  }, {
    id: 'testflix',
    name: 'Video-Streaming',
    merchant: 'Testflix',
    amount: -9.99,
    cycle: 'Monatlich',
    cat: 'abos',
    next: '03.08.2026',
    status: 'aktiv'
  }, {
    id: 'strom',
    name: 'Strom',
    merchant: 'Stadtwerke München',
    amount: -84.00,
    cycle: 'Monatlich',
    cat: 'wohnen',
    next: '01.08.2026',
    status: 'aktiv'
  }, {
    id: 'dazn',
    name: 'Sport-Streaming',
    merchant: 'DAZN',
    amount: -34.99,
    cycle: 'Monatlich',
    cat: 'abos',
    next: '—',
    status: 'beendet'
  }];

  // Category spend for current month (Ausgaben nach Kategorie)
  const catSpend = [{
    key: 'wohnen',
    value: 974.00
  }, {
    key: 'lebensmittel',
    value: 412.30
  }, {
    key: 'mobilitaet',
    value: 310.56
  }, {
    key: 'freizeit',
    value: 168.90
  }, {
    key: 'versicherung',
    value: 145.20
  }, {
    key: 'abos',
    value: 95.96
  }, {
    key: 'gesundheit',
    value: 80.51
  }];

  // 6-month income vs expense
  const trend = [{
    label: 'Feb',
    values: [3180, 2210]
  }, {
    label: 'Mär',
    values: [3240, 2540]
  }, {
    label: 'Apr',
    values: [3240, 2080]
  }, {
    label: 'Mai',
    values: [3390, 2450]
  }, {
    label: 'Jun',
    values: [3240, 2360]
  }, {
    label: 'Jul',
    values: [3240, 2187]
  }];
  const topMerchants = [{
    name: 'Vermieter Weber',
    count: 1,
    amount: -890.00
  }, {
    name: 'REWE',
    count: 6,
    amount: -238.44
  }, {
    name: 'Stadtwerke München',
    count: 1,
    amount: -84.00
  }, {
    name: 'Shell Tankstelle',
    count: 2,
    amount: -71.20
  }, {
    name: 'Amazon',
    count: 4,
    amount: -96.30
  }];
  const reviewQueue = [{
    id: 'r1',
    name: 'PayPal ·88213',
    amount: -42.10,
    guess: 'Freizeit',
    acct: 'DKB Girokonto'
  }, {
    id: 'r2',
    name: 'Amazon',
    amount: -34.99,
    guess: 'Sonstiges',
    acct: 'N26 Hauptkonto'
  }, {
    id: 'r3',
    name: 'SumUp ·Café Ost',
    amount: -8.40,
    guess: 'Lebensmittel',
    acct: 'DKB Girokonto'
  }];
  const kpis = {
    saldo: 13872.27,
    einnahmen: 3240.00,
    ausgaben: 2187.43,
    abos: 233.35
  };

  // group txns by date, German heading
  function groupByDate(list) {
    const months = ['Jan.', 'Feb.', 'März', 'Apr.', 'Mai', 'Juni', 'Juli', 'Aug.', 'Sep.', 'Okt.', 'Nov.', 'Dez.'];
    const groups = {};
    list.forEach(t => {
      const [y, m, d] = t.date.split('-').map(Number);
      const key = `${String(d).padStart(2, '0')}. ${months[m - 1]} ${y}`;
      (groups[key] = groups[key] || []).push(t);
    });
    return Object.entries(groups).map(([label, items]) => ({
      label,
      items,
      sum: items.reduce((s, t) => s + t.amount, 0)
    }));
  }
  function shortDate(iso) {
    const [, m, d] = iso.split('-');
    return `${d}.${m}.`;
  }
  window.FIN = {
    CAT,
    fmtEUR,
    accounts,
    txns,
    contracts,
    catSpend,
    trend,
    topMerchants,
    reviewQueue,
    kpis,
    groupByDate,
    shortDate
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/financiero/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.FilterChip = __ds_scope.FilterChip;

__ds_ns.FilterPill = __ds_scope.FilterPill;

__ds_ns.SearchField = __ds_scope.SearchField;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.BarChart = __ds_scope.BarChart;

__ds_ns.DonutChart = __ds_scope.DonutChart;

__ds_ns.TransactionRow = __ds_scope.TransactionRow;

__ds_ns.ICONS = __ds_scope.ICONS;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Sidebar = __ds_scope.Sidebar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.KpiCard = __ds_scope.KpiCard;

})();
