---
name: financiero-design
description: Use this skill to generate well-branded interfaces and assets for Financiero (German personal-finance web app — CSV import, AI transaction categorization, contracts, analytics), either for production or throwaway prototypes/mocks. Contains design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick orientation
- **Direction:** modern, calm, trustworthy premium fintech. Card-based layout on warm greige, big friendly tabular numbers, exactly one accent color (Marine `#223A7A`) for actions.
- **Tokens:** `styles.css` (entry) → `tokens/` (colors, typography, spacing, radii-shadows, fonts). Marine accent, warm greige bg, green income / red expense semantics, 8-color chart palette. No purple, no mint, no emojis.
- **Type:** Inter (UI/body) + Space Grotesk (display headings & numbers). All money/KPIs use `tabular-nums`, right-aligned. German number format (`1.043,72 €`).
- **Components** (`components/`): Icon, Button, SegmentedControl, FilterPill, FilterChip, SearchField, Card, KpiCard, Badge, EmptyState, Sidebar, TransactionRow, DonutChart, BarChart. Import via `window.FinancieroDesignSystem_<id>` after loading `_ds_bundle.js`, or read the `.jsx` to lift exact values.
- **UI kit** (`ui_kits/financiero/`): full desktop app (Dashboard, Transaktionen, Analyse, Verträge, Einstellungen) + mobile Dashboard/Transaktionen with bottom tab bar. Realistic German sample data in `data.js`.
- **Iconography:** Lucide stroke icons (1.75px) via the `Icon` component. Never emoji.
- **Voice:** German, informal "du", sentence case, calm and non-salesy, no exclamation marks.
