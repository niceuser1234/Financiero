import * as React from 'react';

export interface CardProps {
  /** Card heading (rendered in the header row). */
  title?: string;
  /** Optional sub-line under the title. */
  subtitle?: string;
  /** Right-aligned header slot — a Button, SegmentedControl, or menu. */
  action?: React.ReactNode;
  children?: React.ReactNode;
  /** Inner padding; defaults to `var(--card-pad)` (24px). */
  pad?: string;
  style?: React.CSSProperties;
  bodyStyle?: React.CSSProperties;
}

/** The base white floating surface. Everything on a screen sits in a Card. */
export function Card(props: CardProps): JSX.Element;
