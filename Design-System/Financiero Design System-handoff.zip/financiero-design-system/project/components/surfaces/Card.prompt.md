**Card** — the base white floating surface; soft diffuse shadow, 16px radius. Everything on a Financiero screen lives in a Card. Pass `title`/`subtitle`/`action` for the standard header row, or just children for a bare container.

```jsx
<Card title="Ausgaben nach Kategorie" action={<Button variant="ghost" size="sm">Alle</Button>}>
  …
</Card>
```
