import React from 'react';
import { Icon } from '../icons/Icon.jsx';

/** Empty state: centered icon in a soft disc, title, message, optional action. For empty charts/lists. */
export function EmptyState({ icon = 'inbox', title, message, action, compact, style }) {
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center',
      padding: compact ? '28px 24px' : '48px 32px', gap: 4, ...style,
    }}>
      <div style={{
        width: compact ? 44 : 56, height: compact ? 44 : 56, borderRadius: 'var(--radius-lg)',
        display: 'grid', placeItems: 'center', background: 'var(--surface-sunken)',
        color: 'var(--ink-400)', marginBottom: 12,
      }}>
        <Icon name={icon} size={compact ? 22 : 26} strokeWidth={1.75} />
      </div>
      {title && <div style={{ font: `var(--fw-semibold) var(--text-title)/1.3 var(--font-sans)`, color: 'var(--ink-900)' }}>{title}</div>}
      {message && <div style={{ font: `var(--fw-regular) var(--text-sm)/1.5 var(--font-sans)`, color: 'var(--ink-500)', maxWidth: 320 }}>{message}</div>}
      {action && <div style={{ marginTop: 16 }}>{action}</div>}
    </div>
  );
}
