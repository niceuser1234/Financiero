import * as React from 'react';
import type { IconName } from '../icons/Icon';

export interface BadgeProps {
  children?: React.ReactNode;
  /** Semantic tone. `review` = muted amber "Prüfen"; `uncat` = neutral "Nicht kategorisiert". */
  tone?: 'neutral' | 'accent' | 'income' | 'expense' | 'review' | 'uncat';
  /** Optional leading icon (e.g. `repeat` for recurring, `triangle-alert` for review). */
  icon?: IconName;
  style?: React.CSSProperties;
}

/** Small status/category pill. Carries Financiero's semantic colors (income/expense/review/uncategorized). */
export function Badge(props: BadgeProps): JSX.Element;
