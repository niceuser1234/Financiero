**KpiCard** — the big-number tile that is Financiero's visual signature. Uppercase eyebrow, large Space Grotesk tabular value, optional delta with trend arrow. `tone` picks the tint: `income` (green), `expense` (red), `accent` (filled marine, e.g. Gesamtsaldo), or `neutral` (white).

```jsx
<KpiCard tone="income" label="Einnahmen" value="3.240,00 €" delta="4,2 % ggü. Vormonat" deltaDir="up" />
<KpiCard tone="expense" label="Ausgaben" value="2.187,43 €" delta="1,8 % ggü. Vormonat" deltaDir="up" />
<KpiCard tone="accent" label="Gesamtsaldo" value="4.812,05 €" icon="wallet" />
```
