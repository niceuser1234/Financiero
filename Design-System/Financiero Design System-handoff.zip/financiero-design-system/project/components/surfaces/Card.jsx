import React from 'react';

/** White floating card — the base container. Soft diffuse shadow, radius-lg, optional title/action header. */
export function Card({ title, subtitle, action, children, pad = 'var(--card-pad)', style, bodyStyle }) {
  return (
    <section style={{
      background: 'var(--surface)', borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-md)', border: '1px solid var(--hairline)',
      padding: pad, ...style,
    }}>
      {(title || action) && (
        <header style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, marginBottom: 18 }}>
          <div>
            {title && <h3 style={{ margin: 0, font: `var(--fw-semibold) var(--text-title)/1.2 var(--font-sans)`, color: 'var(--ink-900)', letterSpacing: '-.01em' }}>{title}</h3>}
            {subtitle && <p style={{ margin: '4px 0 0', font: `var(--fw-regular) var(--text-sm)/1.3 var(--font-sans)`, color: 'var(--ink-500)' }}>{subtitle}</p>}
          </div>
          {action}
        </header>
      )}
      <div style={bodyStyle}>{children}</div>
    </section>
  );
}
