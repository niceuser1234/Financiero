import React from 'react';
import { Icon } from '../icons/Icon.jsx';

const TONES = {
  neutral: { bg: 'var(--surface-sunken)', fg: 'var(--ink-500)' },
  accent: { bg: 'var(--accent-soft)', fg: 'var(--accent)' },
  income: { bg: 'var(--income-soft-bg)', fg: 'var(--income)' },
  expense: { bg: 'var(--expense-soft-bg)', fg: 'var(--expense-strong)' },
  review: { bg: 'var(--review-soft-bg)', fg: 'var(--review)' },
  uncat: { bg: 'var(--uncat-soft-bg)', fg: 'var(--uncat)' },
};

/** Small pill label for status/category. `tone` sets semantic colors; optional leading icon. */
export function Badge({ children, tone = 'neutral', icon, style }) {
  const t = TONES[tone] || TONES.neutral;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: icon ? '4px 10px 4px 8px' : '4px 10px', borderRadius: 'var(--radius-pill)',
      background: t.bg, color: t.fg,
      font: `var(--fw-semibold) var(--text-xs)/1 var(--font-sans)`, whiteSpace: 'nowrap', ...style,
    }}>
      {icon && <Icon name={icon} size={13} strokeWidth={2} />}
      {children}
    </span>
  );
}
