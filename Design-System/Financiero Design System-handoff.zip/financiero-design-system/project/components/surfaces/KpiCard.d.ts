import * as React from 'react';
import type { IconName } from '../icons/Icon';

export interface KpiCardProps {
  /** Uppercase eyebrow, e.g. "EINNAHMEN". */
  label: string;
  /** Formatted value string, e.g. "3.240,00 €". Rendered in display font with tabular-nums. */
  value: string;
  /** Optional change line, e.g. "4,2 % ggü. Vormonat". */
  delta?: string;
  /** Colors + arrow for the delta. */
  deltaDir?: 'up' | 'down';
  /** Optional icon top-right. */
  icon?: IconName;
  /** Tint. `income`/`expense` use semantic soft backgrounds; `accent` = filled marine; `neutral` = white. */
  tone?: 'neutral' | 'income' | 'expense' | 'accent';
  style?: React.CSSProperties;
}

/** The big friendly number — Financiero's visual signature. Used across Dashboard & Analyse. */
export function KpiCard(props: KpiCardProps): JSX.Element;
