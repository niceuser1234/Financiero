**EmptyState** — centered icon-in-a-disc + title + message for empty charts, filtered-to-nothing lists, and empty review queues. Use `compact` inside a chart card.

```jsx
<EmptyState compact icon="pie-chart" title="Keine Ausgaben"
  message="Keine Ausgaben im gewählten Zeitraum." />
<EmptyState icon="inbox" title="Alles geprüft"
  message="Die Review-Queue ist leer." />
```
