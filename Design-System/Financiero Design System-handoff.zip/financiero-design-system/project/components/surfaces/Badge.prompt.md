**Badge** — small semantic pill for status and category. Tones map to Financiero's semantics: `review` (muted amber "Prüfen"), `uncat` (neutral gray "Nicht kategorisiert"), `income`/`expense`, `accent`, `neutral`.

```jsx
<Badge tone="review" icon="triangle-alert">Prüfen</Badge>
<Badge tone="uncat">Nicht kategorisiert</Badge>
<Badge tone="neutral" icon="repeat">Monatlich</Badge>
```
