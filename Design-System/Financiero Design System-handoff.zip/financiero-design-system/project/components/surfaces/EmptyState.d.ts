import * as React from 'react';
import type { IconName } from '../icons/Icon';

export interface EmptyStateProps {
  /** Icon in the soft disc. Default `inbox`. */
  icon?: IconName;
  title?: string;
  /** Supporting line, e.g. "Keine Ausgaben im gewählten Zeitraum." */
  message?: string;
  /** Optional CTA (usually a Button). */
  action?: React.ReactNode;
  /** Tighter padding for inside a chart card. */
  compact?: boolean;
  style?: React.CSSProperties;
}

/** Centered empty state for empty charts, filtered-to-nothing lists, and empty queues. */
export function EmptyState(props: EmptyStateProps): JSX.Element;
