import React from 'react';
import { Icon } from '../icons/Icon.jsx';

const TONES = {
  neutral: { bg: 'var(--surface)', label: 'var(--ink-400)', value: 'var(--ink-900)', delta: 'var(--ink-500)', border: '1px solid var(--hairline)' },
  income: { bg: 'var(--income-soft-bg)', label: 'var(--income-mid)', value: 'var(--income)', delta: 'var(--income-mid)', border: '1px solid transparent' },
  expense: { bg: 'var(--expense-soft-bg)', label: 'var(--expense)', value: 'var(--expense-strong)', delta: 'var(--expense)', border: '1px solid transparent' },
  accent: { bg: 'var(--accent)', label: 'rgba(255,255,255,.75)', value: '#fff', delta: 'rgba(255,255,255,.85)', border: '1px solid transparent' },
};

/** KPI tile: uppercase eyebrow, big Space Grotesk tabular value, optional delta. Financiero's signature. */
export function KpiCard({ label, value, delta, deltaDir, icon, tone = 'neutral', style }) {
  const t = TONES[tone] || TONES.neutral;
  const dirIcon = deltaDir === 'up' ? 'trending-up' : deltaDir === 'down' ? 'trending-down' : null;
  return (
    <div style={{
      background: t.bg, border: t.border, borderRadius: 'var(--radius-lg)',
      boxShadow: tone === 'neutral' ? 'var(--shadow-md)' : (tone === 'accent' ? 'var(--shadow-accent)' : 'none'),
      padding: '20px 22px', ...style,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <span style={{ font: `var(--fw-semibold) var(--text-2xs)/1 var(--font-sans)`, letterSpacing: 'var(--tracking-label)', textTransform: 'uppercase', color: t.label }}>{label}</span>
        {icon && <Icon name={icon} size={17} color={t.label} />}
      </div>
      <div style={{
        marginTop: 12, font: `var(--fw-bold) var(--text-kpi)/1 var(--font-display)`,
        letterSpacing: 'var(--tracking-tight)', color: t.value,
        fontVariantNumeric: 'tabular-nums', fontFeatureSettings: '"tnum" 1',
      }}>{value}</div>
      {delta && (
        <div style={{ marginTop: 8, display: 'flex', alignItems: 'center', gap: 5, font: `var(--fw-medium) var(--text-sm)/1 var(--font-sans)`, color: t.delta, fontVariantNumeric: 'tabular-nums' }}>
          {dirIcon && <Icon name={dirIcon} size={15} strokeWidth={2} />}
          {delta}
        </div>
      )}
    </div>
  );
}
