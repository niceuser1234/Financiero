**Sidebar** — the desktop primary navigation. Fixed 240px, brand mark on top, five nav items (Dashboard · Transaktionen · Verträge · Analyse · Einstellungen). Active item is a filled marine pill with soft accent shadow; inactive is muted ink; hover lightens the row.

```jsx
const [page, setPage] = React.useState('analyse');
<Sidebar active={page} onNavigate={setPage} />
```

Default `items` match the app's IA exactly. Pass `footer` for a sync button or account card.
