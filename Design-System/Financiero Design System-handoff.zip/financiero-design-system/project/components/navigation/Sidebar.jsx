import React from 'react';
import { Icon } from '../icons/Icon.jsx';

const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: 'layout-dashboard' },
  { id: 'transaktionen', label: 'Transaktionen', icon: 'arrow-left-right' },
  { id: 'vertraege', label: 'Verträge', icon: 'repeat' },
  { id: 'analyse', label: 'Analyse', icon: 'pie-chart' },
  { id: 'einstellungen', label: 'Einstellungen', icon: 'settings' },
];

function NavItem({ item, active, onClick }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button onClick={() => onClick && onClick(item.id)}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 12, width: '100%', textAlign: 'left',
        padding: '11px 12px', borderRadius: 'var(--radius-md)', border: 0, cursor: 'pointer',
        font: `${active ? 'var(--fw-semibold)' : 'var(--fw-medium)'} 14.5px/1 var(--font-sans)`,
        background: active ? 'var(--accent)' : (hover ? 'var(--surface-hover)' : 'transparent'),
        color: active ? 'var(--accent-fg)' : (hover ? 'var(--ink-900)' : 'var(--ink-500)'),
        boxShadow: active ? 'var(--shadow-accent)' : 'none',
        transition: 'background var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)',
      }}>
      <Icon name={item.icon} size={19} strokeWidth={active ? 2 : 1.75} />
      {item.label}
    </button>
  );
}

/** Desktop sidebar navigation. Active item = filled marine pill; hover lightens the row. */
export function Sidebar({ active = 'analyse', onNavigate, items = NAV, footer, style }) {
  return (
    <aside style={{
      width: 'var(--sidebar-w)', flex: 'none', minHeight: '100%',
      display: 'flex', flexDirection: 'column', padding: '26px 16px 20px',
      background: 'var(--bg)', ...style,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 9, padding: '0 12px 26px' }}>
        <span style={{ display: 'grid', placeItems: 'center', width: 30, height: 30, borderRadius: 9, background: 'var(--accent)', color: '#fff' }}>
          <Icon name="wallet" size={17} strokeWidth={2} />
        </span>
        <span style={{ font: `var(--fw-bold) 19px/1 var(--font-display)`, letterSpacing: '-.015em', color: 'var(--ink-900)' }}>Financiero</span>
      </div>
      <nav style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        {items.map((it) => <NavItem key={it.id} item={it} active={it.id === active} onClick={onNavigate} />)}
      </nav>
      <div style={{ marginTop: 'auto' }}>{footer}</div>
    </aside>
  );
}
