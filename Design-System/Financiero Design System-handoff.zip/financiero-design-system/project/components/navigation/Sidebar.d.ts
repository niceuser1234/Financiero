import * as React from 'react';
import type { IconName } from '../icons/Icon';

export interface NavEntry { id: string; label: string; icon: IconName; }

export interface SidebarProps {
  /** Currently active nav id. Default `analyse`. */
  active?: string;
  onNavigate?: (id: string) => void;
  /** Override the nav entries. Defaults to Financiero's 5-item IA. */
  items?: NavEntry[];
  /** Optional bottom slot (user card, sync button). */
  footer?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Financiero desktop sidebar: brand mark + 5-item nav. Active = filled marine pill, hover lightens. */
export function Sidebar(props: SidebarProps): JSX.Element;
