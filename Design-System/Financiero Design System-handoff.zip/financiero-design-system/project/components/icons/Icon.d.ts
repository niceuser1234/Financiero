import * as React from 'react';

export type IconName =
  | 'layout-dashboard' | 'arrow-left-right' | 'repeat' | 'pie-chart' | 'settings'
  | 'refresh-cw' | 'search' | 'sliders-horizontal' | 'upload' | 'building-2'
  | 'landmark' | 'circle-check' | 'triangle-alert' | 'plus' | 'x'
  | 'chevron-down' | 'chevron-right' | 'arrow-up-right' | 'arrow-down-right'
  | 'ellipsis' | 'calendar' | 'trash-2' | 'credit-card' | 'wallet'
  | 'trending-up' | 'trending-down' | 'bell' | 'inbox' | 'file-text'
  | 'plug' | 'log-out' | 'shield-check';

export interface IconProps extends React.SVGProps<SVGSVGElement> {
  /** Lucide icon id. */
  name: IconName;
  /** Pixel size (width & height). Default 20. */
  size?: number;
  /** Stroke width. Default 1.75 to match Financiero's calm stroke icons. */
  strokeWidth?: number;
  /** Override stroke color; defaults to currentColor. */
  color?: string;
}

/** Financiero's only icon primitive: a Lucide stroke glyph rendered inline as SVG. */
export function Icon(props: IconProps): JSX.Element | null;

export declare const ICONS: Record<IconName, string>;
