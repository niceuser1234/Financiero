**Icon** — Financiero's single icon primitive: a Lucide stroke glyph (1.75px weight) rendered inline as SVG, coloring via `currentColor`. Use it everywhere an icon is needed; never emoji or unicode symbols.

```jsx
<Icon name="pie-chart" size={20} />
<Icon name="refresh-cw" size={16} color="var(--accent)" />
```

Available `name`s cover the app's nav and actions: `layout-dashboard`, `arrow-left-right`, `repeat`, `pie-chart`, `settings`, `refresh-cw`, `search`, `sliders-horizontal`, `upload`, `building-2`, `landmark`, `circle-check`, `triangle-alert`, `plus`, `x`, `chevron-down`, `chevron-right`, `arrow-up-right`, `arrow-down-right`, `ellipsis`, `calendar`, `trash-2`, `credit-card`, `wallet`, `trending-up`, `trending-down`, `bell`, `inbox`, `file-text`, `plug`, `log-out`, `shield-check`.
