import React from 'react';
import { Icon } from '../icons/Icon.jsx';
import { Badge } from '../surfaces/Badge.jsx';

/**
 * Single transaction row: merchant avatar (initial), name + meta, optional category badge,
 * signed amount (green income / red expense, tabular right-aligned), recurring & review markers.
 */
export function TransactionRow({
  name, meta, amount, direction, category, categoryTone = 'neutral',
  recurring, review, uncategorized, avatarColor, onClick, style,
}) {
  const [hover, setHover] = React.useState(false);
  const initial = (name || '?').trim().charAt(0).toUpperCase();
  const isIncome = direction === 'income';
  return (
    <div onClick={onClick} onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        display: 'flex', alignItems: 'center', gap: 14, padding: '0 12px',
        height: 64, borderRadius: 'var(--radius-md)', cursor: onClick ? 'pointer' : 'default',
        background: hover ? 'var(--surface-hover)' : 'transparent',
        transition: 'background var(--dur-fast) var(--ease-out)', ...style,
      }}>
      <span style={{
        width: 38, height: 38, flex: 'none', borderRadius: 'var(--radius-sm)', display: 'grid', placeItems: 'center',
        background: avatarColor || 'var(--accent-soft)', color: avatarColor ? '#fff' : 'var(--accent)',
        font: `var(--fw-semibold) 14px/1 var(--font-sans)`,
      }}>{initial}</span>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ font: `var(--fw-medium) var(--text-body)/1.2 var(--font-sans)`, color: 'var(--ink-900)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{name}</span>
          {recurring && <Icon name="repeat" size={14} color="var(--ink-400)" strokeWidth={2} />}
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 3 }}>
          {meta && <span style={{ font: `var(--fw-regular) var(--text-xs)/1.2 var(--font-sans)`, color: 'var(--ink-400)' }}>{meta}</span>}
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {uncategorized
          ? <Badge tone="uncat">Nicht kategorisiert</Badge>
          : (category && <Badge tone={categoryTone}>{category}</Badge>)}
        {review && <Badge tone="review" icon="triangle-alert">Prüfen</Badge>}
        <span style={{
          minWidth: 104, textAlign: 'right',
          font: `var(--fw-semibold) 15px/1 var(--font-display)`, letterSpacing: '-.01em',
          fontVariantNumeric: 'tabular-nums', fontFeatureSettings: '"tnum" 1',
          color: isIncome ? 'var(--income)' : 'var(--ink-900)',
        }}>{amount}</span>
      </div>
    </div>
  );
}
