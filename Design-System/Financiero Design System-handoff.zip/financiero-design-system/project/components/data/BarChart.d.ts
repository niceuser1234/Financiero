import * as React from 'react';

export interface BarGroup {
  /** X-axis label, e.g. "Jul". */
  label: string;
  /** One value per series (income, expense …). */
  values: number[];
}

export interface BarSeries { name: string; color: string; }

export interface BarChartProps {
  data: BarGroup[];
  /** Series metadata; length should match each group's `values`. Renders a legend. */
  series?: BarSeries[];
  /** Plot height px (excludes labels/legend). Default 150. */
  height?: number;
  /** Emphasize the last group (current period), fade the rest. */
  highlightLast?: boolean;
  /** Rendered when all values are 0 (pass an EmptyState). */
  empty?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Bar chart for "Einnahmen vs. Ausgaben über 6 Monate" (grouped) or single-series trends. */
export function BarChart(props: BarChartProps): JSX.Element;
