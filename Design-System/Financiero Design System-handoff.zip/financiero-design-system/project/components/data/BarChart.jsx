import React from 'react';

/**
 * Grouped/single bar chart. `data` = [{label, values:[n,...]}]; `series` = [{name,color}].
 * Bars share a max scale. `highlightLast` emphasizes the final label (current period).
 */
export function BarChart({ data = [], series = [], height = 150, highlightLast, empty, style }) {
  const allVals = data.flatMap((d) => d.values || []);
  const max = Math.max(1, ...allVals);
  if (allVals.every((v) => !v) && empty) return <div style={style}>{empty}</div>;

  return (
    <div style={{ ...style }}>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 18, height, paddingTop: 8 }}>
        {data.map((d, i) => {
          const last = i === data.length - 1;
          return (
            <div key={i} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 9, height: '100%' }}>
              <div style={{ flex: 1, width: '100%', display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 5 }}>
                {(d.values || []).map((v, j) => (
                  <div key={j} title={`${series[j] ? series[j].name : ''}`}
                    style={{
                      width: series.length > 1 ? 13 : 22,
                      height: `${(v / max) * 100}%`, minHeight: v > 0 ? 3 : 0,
                      borderRadius: '6px 6px 0 0',
                      background: (series[j] && series[j].color) || 'var(--chart-1)',
                      opacity: highlightLast && !last ? 0.55 : 1,
                      transition: 'height var(--dur) var(--ease-out)',
                    }} />
                ))}
              </div>
              <span style={{ font: `${highlightLast && last ? 'var(--fw-bold)' : 'var(--fw-medium)'} 11.5px/1 var(--font-sans)`, color: highlightLast && last ? 'var(--ink-900)' : 'var(--ink-400)' }}>{d.label}</span>
            </div>
          );
        })}
      </div>
      {series.length > 0 && (
        <div style={{ display: 'flex', gap: 18, marginTop: 16, paddingTop: 14, borderTop: '1px solid var(--hairline)' }}>
          {series.map((s, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 7, font: `var(--fw-medium) 12.5px/1 var(--font-sans)`, color: 'var(--ink-500)' }}>
              <span style={{ width: 9, height: 9, borderRadius: 3, background: s.color }} />{s.name}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
