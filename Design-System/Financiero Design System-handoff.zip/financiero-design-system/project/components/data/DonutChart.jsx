import React from 'react';

const DEFAULT_COLORS = ['var(--chart-1)', 'var(--chart-2)', 'var(--chart-3)', 'var(--chart-4)', 'var(--chart-5)', 'var(--chart-6)', 'var(--chart-7)', 'var(--chart-8)'];

/**
 * Donut chart. `data` = [{label, value, color?}]. Renders an SVG ring + center total + legend.
 * When total is 0, shows the `empty` slot (pass an EmptyState).
 */
export function DonutChart({ data = [], size = 150, thickness = 20, centerLabel = 'GESAMT', centerValue, legend = true, empty, style }) {
  const total = data.reduce((s, d) => s + (d.value || 0), 0);
  if (total <= 0 && empty) return <div style={style}>{empty}</div>;

  const r = (size - thickness) / 2;
  const c = 2 * Math.PI * r;
  let acc = 0;
  const segs = data.map((d, i) => {
    const frac = total > 0 ? d.value / total : 0;
    const seg = { color: d.color || DEFAULT_COLORS[i % DEFAULT_COLORS.length], dash: frac * c, offset: -acc * c, ...d, frac };
    acc += frac;
    return seg;
  });

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 26, ...style }}>
      <div style={{ position: 'relative', width: size, height: size, flex: 'none' }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} style={{ transform: 'rotate(-90deg)' }}>
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-sunken)" strokeWidth={thickness} />
          {segs.map((s, i) => (
            <circle key={i} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={s.color}
              strokeWidth={thickness} strokeDasharray={`${s.dash} ${c - s.dash}`} strokeDashoffset={s.offset}
              strokeLinecap="butt" />
          ))}
        </svg>
        <div style={{ position: 'absolute', inset: 0, display: 'grid', placeContent: 'center', textAlign: 'center' }}>
          <div style={{ font: `var(--fw-semibold) 9.5px/1 var(--font-sans)`, letterSpacing: 'var(--tracking-label)', color: 'var(--ink-400)' }}>{centerLabel}</div>
          <div style={{ marginTop: 3, font: `var(--fw-bold) 17px/1 var(--font-display)`, letterSpacing: '-.01em', color: 'var(--ink-900)', fontVariantNumeric: 'tabular-nums' }}>{centerValue}</div>
        </div>
      </div>
      {legend && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 11, flex: 1, minWidth: 0 }}>
          {segs.map((s, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, font: `var(--fw-regular) 13px/1 var(--font-sans)`, color: 'var(--ink-700)' }}>
              <span style={{ width: 9, height: 9, borderRadius: 3, background: s.color, flex: 'none' }} />
              <span style={{ flex: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{s.label}</span>
              <span style={{ font: `var(--fw-semibold) 13px/1 var(--font-sans)`, color: 'var(--ink-900)', fontVariantNumeric: 'tabular-nums' }}>{s.display != null ? s.display : s.value}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
