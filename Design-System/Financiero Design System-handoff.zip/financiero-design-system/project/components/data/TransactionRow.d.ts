import * as React from 'react';

export interface TransactionRowProps {
  /** Merchant / counterparty, e.g. "REWE", "Vermieter Weber". */
  name: string;
  /** Secondary line: account, time, or note, e.g. "DKB Girokonto · 14:32". */
  meta?: string;
  /** Pre-formatted signed amount, e.g. "−9,99 €" or "3.240,00 €". */
  amount: string;
  /** `income` renders green; anything else renders neutral ink for expenses. */
  direction?: 'income' | 'expense';
  /** Category label shown as a Badge. */
  category?: string;
  /** Badge tone for the category. */
  categoryTone?: 'neutral' | 'accent' | 'income' | 'expense' | 'review' | 'uncat';
  /** Show the recurring (repeat) glyph after the name. */
  recurring?: boolean;
  /** Show the amber "Prüfen" badge (AI unsure / needs review). */
  review?: boolean;
  /** Render the neutral "Nicht kategorisiert" badge instead of a category. */
  uncategorized?: boolean;
  /** Solid avatar background (else accent-soft tint with accent initial). */
  avatarColor?: string;
  onClick?: () => void;
  style?: React.CSSProperties;
}

/** One row in the transaction list: avatar, name+meta, category/review badges, signed tabular amount. */
export function TransactionRow(props: TransactionRowProps): JSX.Element;
