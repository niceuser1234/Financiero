**BarChart** — "Einnahmen vs. Ausgaben über 6 Monate". Grouped bars sharing one scale, with a legend. Use `highlightLast` to emphasize the current month. Income/expense use the semantic mid colors.

```jsx
<BarChart highlightLast
  series={[{name:'Einnahmen', color:'var(--income-mid)'}, {name:'Ausgaben', color:'var(--expense)'}]}
  data={[
    {label:'Feb', values:[3100, 2200]},
    {label:'Mär', values:[3240, 2450]},
    {label:'Jul', values:[3240, 2187]},
  ]} />
```
