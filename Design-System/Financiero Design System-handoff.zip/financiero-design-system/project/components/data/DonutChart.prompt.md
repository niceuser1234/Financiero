**DonutChart** — "Ausgaben nach Kategorie" ring with a center total and a legend. Feed `data` as `{label, value, display?}`; colors auto-fill from the chart palette. Pass `empty` (an EmptyState) so a zero total renders "Keine Ausgaben im Zeitraum" instead of an empty ring.

```jsx
<DonutChart size={150} centerValue="2.187 €"
  data={[
    {label:'Wohnen', value:890, display:'890,00 €'},
    {label:'Lebensmittel', value:412, display:'412,30 €'},
    {label:'Mobilität', value:311, display:'310,56 €'},
  ]}
  empty={<EmptyState compact icon="pie-chart" title="Keine Ausgaben" message="Keine Ausgaben im Zeitraum." />} />
```
