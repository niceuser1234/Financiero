import * as React from 'react';

export interface DonutSegment {
  label: string;
  /** Numeric magnitude used to size the arc. */
  value: number;
  /** Optional pre-formatted display string for the legend (e.g. "890,00 €"). */
  display?: string;
  /** Override color; defaults to the chart palette in order. */
  color?: string;
}

export interface DonutChartProps {
  data: DonutSegment[];
  /** Diameter px. Default 150. */
  size?: number;
  /** Ring thickness px. Default 20. */
  thickness?: number;
  /** Center eyebrow. Default "GESAMT". */
  centerLabel?: string;
  /** Center big value (formatted). */
  centerValue?: string;
  /** Show the legend column. Default true. */
  legend?: boolean;
  /** Rendered instead of the ring when the total is 0 (pass an EmptyState). */
  empty?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Category-breakdown donut with center total + legend. Uses the 8-color chart palette. */
export function DonutChart(props: DonutChartProps): JSX.Element;
