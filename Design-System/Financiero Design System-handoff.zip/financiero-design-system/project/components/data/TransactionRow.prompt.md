**TransactionRow** — one line in the Transaktionen list. Merchant avatar (initial in a tinted square), name + meta, category badge, and the signed amount in tabular display figures, right-aligned. Income is green; expenses are neutral ink. Flags: `recurring` (repeat glyph), `review` (amber "Prüfen"), `uncategorized` (neutral badge).

```jsx
<TransactionRow name="Testflix" meta="DKB Girokonto · 03.07." amount="−9,99 €"
  direction="expense" category="Abos" recurring />
<TransactionRow name="Gehalt Muster GmbH" meta="DKB Girokonto · 30.06." amount="3.240,00 €"
  direction="income" category="Einkommen" categoryTone="income" />
<TransactionRow name="PayPal ·88213" meta="DKB Girokonto · 02.07." amount="−42,10 €"
  direction="expense" uncategorized review />
```
