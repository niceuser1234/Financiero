import * as React from 'react';

export interface SegmentOption { value: string; label: string; }

export interface SegmentedControlProps {
  /** Options as `{value,label}` objects or plain strings. */
  options: (SegmentOption | string)[];
  /** Currently selected value. */
  value: string;
  onChange?: (value: string) => void;
  /** Default `md`. */
  size?: 'sm' | 'md';
  style?: React.CSSProperties;
}

/** Segmented control for period/scope toggles (e.g. Monat / 3 Monate / 1 Jahr). Active pill filled marine. */
export function SegmentedControl(props: SegmentedControlProps): JSX.Element;
