**FilterChip** — represents one *applied* filter above the Transaktionen list, with a dismiss ✕. Distinct from FilterPill (which opens/toggles filters); chips show what's currently active.

```jsx
<FilterChip label="Konto" value="DKB Girokonto" onRemove={clear} />
<FilterChip label="Zeitraum" value="Juli 2026" onRemove={clear} />
```
