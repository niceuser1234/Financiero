import React from 'react';
import { Icon } from '../icons/Icon.jsx';

/** Filter pill (rounded-full). Toggleable; `count` shows a badge; `dropdown` adds a chevron. */
export function FilterPill({ children, active, count, dropdown, icon, onClick, style }) {
  return (
    <button onClick={onClick}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 7,
        padding: '8px 14px', borderRadius: 'var(--radius-pill)', cursor: 'pointer',
        font: `var(--fw-medium) 13px/1 var(--font-sans)`,
        background: active ? 'var(--accent-soft)' : 'var(--surface)',
        color: active ? 'var(--accent)' : 'var(--ink-700)',
        border: `1px solid ${active ? 'transparent' : 'var(--hairline-strong)'}`,
        boxShadow: active ? 'none' : 'var(--shadow-xs)',
        transition: 'background var(--dur-fast) var(--ease-out)', whiteSpace: 'nowrap',
      }}
      onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = 'var(--surface-hover)'; }}
      onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = 'var(--surface)'; }}
    >
      {icon && <Icon name={icon} size={15} strokeWidth={2} />}
      {children}
      {count != null && (
        <span style={{
          fontVariantNumeric: 'tabular-nums', fontWeight: 'var(--fw-semibold)', fontSize: 11,
          minWidth: 18, height: 18, padding: '0 5px', borderRadius: 'var(--radius-pill)',
          display: 'inline-grid', placeItems: 'center',
          background: active ? 'var(--accent)' : 'var(--surface-sunken)',
          color: active ? 'var(--accent-fg)' : 'var(--ink-500)',
        }}>{count}</span>
      )}
      {dropdown && <Icon name="chevron-down" size={15} strokeWidth={2} style={{ marginRight: -2, opacity: .7 }} />}
    </button>
  );
}
