import React from 'react';
import { Icon } from '../icons/Icon.jsx';

const SIZES = {
  sm: { pad: '8px 14px', font: 13, gap: 6, icon: 15, radius: 'var(--radius-md)' },
  md: { pad: '11px 18px', font: 14, gap: 8, icon: 17, radius: 'var(--radius-md)' },
  lg: { pad: '13px 22px', font: 15, gap: 8, icon: 18, radius: 'var(--radius-md)' },
};

const VARIANTS = {
  primary: { background: 'var(--accent)', color: 'var(--accent-fg)', border: '1px solid transparent', boxShadow: 'var(--shadow-accent)' },
  secondary: { background: 'var(--surface)', color: 'var(--ink-900)', border: '1px solid var(--hairline-strong)', boxShadow: 'var(--shadow-xs)' },
  ghost: { background: 'transparent', color: 'var(--ink-700)', border: '1px solid transparent', boxShadow: 'none' },
  danger: { background: 'var(--surface)', color: 'var(--expense)', border: '1px solid var(--hairline-strong)', boxShadow: 'var(--shadow-xs)' },
};

/** Primary action button. One accent color; primary = filled marine with soft accent shadow. */
export function Button({ children, variant = 'primary', size = 'md', icon, iconRight, disabled, style, ...rest }) {
  const s = SIZES[size] || SIZES.md;
  const v = VARIANTS[variant] || VARIANTS.primary;
  return (
    <button
      disabled={disabled}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: s.gap,
        font: `var(--fw-semibold) ${s.font}px/1 var(--font-sans)`, letterSpacing: '.005em',
        padding: s.pad, borderRadius: s.radius, cursor: disabled ? 'not-allowed' : 'pointer',
        transition: `background var(--dur-fast) var(--ease-out), transform var(--dur-fast) var(--ease-out)`,
        opacity: disabled ? 0.45 : 1, whiteSpace: 'nowrap', ...v, ...style,
      }}
      onMouseDown={(e) => { if (!disabled && variant === 'primary') e.currentTarget.style.background = 'var(--accent-active)'; }}
      onMouseUp={(e) => { if (!disabled && variant === 'primary') e.currentTarget.style.background = 'var(--accent-hover)'; }}
      onMouseEnter={(e) => { if (!disabled && variant === 'primary') e.currentTarget.style.background = 'var(--accent-hover)'; if (!disabled && (variant === 'secondary' || variant === 'ghost' || variant === 'danger')) e.currentTarget.style.background = 'var(--surface-hover)'; }}
      onMouseLeave={(e) => { if (!disabled) e.currentTarget.style.background = v.background; }}
      {...rest}
    >
      {icon && <Icon name={icon} size={s.icon} strokeWidth={2} />}
      {children}
      {iconRight && <Icon name={iconRight} size={s.icon} strokeWidth={2} />}
    </button>
  );
}
