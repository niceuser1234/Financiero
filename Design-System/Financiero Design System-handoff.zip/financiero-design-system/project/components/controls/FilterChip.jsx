import React from 'react';
import { Icon } from '../icons/Icon.jsx';

/** Active-filter chip with a dismiss ✕. Shows the applied filter; `onRemove` clears it. */
export function FilterChip({ label, value, onRemove, style }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '6px 6px 6px 12px', borderRadius: 'var(--radius-pill)',
      background: 'var(--accent-soft)', color: 'var(--accent)',
      font: `var(--fw-medium) 12.5px/1 var(--font-sans)`, whiteSpace: 'nowrap', ...style,
    }}>
      {label && <span style={{ opacity: .7 }}>{label}:</span>}
      <span style={{ fontWeight: 'var(--fw-semibold)' }}>{value}</span>
      <button onClick={onRemove} aria-label="Filter entfernen"
        style={{
          display: 'grid', placeItems: 'center', width: 18, height: 18, marginLeft: 1,
          border: 0, borderRadius: 'var(--radius-pill)', cursor: 'pointer',
          background: 'transparent', color: 'var(--accent)',
          transition: 'background var(--dur-fast) var(--ease-out)',
        }}
        onMouseEnter={(e) => { e.currentTarget.style.background = 'rgba(34,58,122,.14)'; }}
        onMouseLeave={(e) => { e.currentTarget.style.background = 'transparent'; }}
      ><Icon name="x" size={13} strokeWidth={2.5} /></button>
    </span>
  );
}
