**SegmentedControl** — mutually-exclusive toggle for period/scope (Zeitraum-Toggle, contract status). Active option is a filled marine pill; the track is a white raised capsule.

```jsx
const [range, setRange] = React.useState('monat');
<SegmentedControl value={range} onChange={setRange}
  options={[{value:'monat',label:'Monat'},{value:'3m',label:'3 Monate'},{value:'jahr',label:'1 Jahr'}]} />
```
