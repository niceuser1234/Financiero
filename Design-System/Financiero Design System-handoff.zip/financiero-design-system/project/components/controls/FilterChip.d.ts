import * as React from 'react';

export interface FilterChipProps {
  /** Optional dimension label shown before the value, e.g. "Konto". */
  label?: string;
  /** The applied value, e.g. "DKB Girokonto". */
  value: string;
  /** Called when the ✕ is clicked. */
  onRemove?: () => void;
  style?: React.CSSProperties;
}

/** A removable chip representing one active filter above the transaction list. */
export function FilterChip(props: FilterChipProps): JSX.Element;
