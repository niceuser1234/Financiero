import * as React from 'react';

export interface SearchFieldProps {
  value?: string;
  onChange?: (value: string) => void;
  /** Default "Suchen …". */
  placeholder?: string;
  /** Called when the trailing ✕ is clicked (only shown when value is non-empty). */
  onClear?: () => void;
  /** Fixed width in px; defaults to 320. */
  width?: number;
  style?: React.CSSProperties;
}

/** Search input with leading magnifier, accent focus ring, and clear button. Used on Transaktionen. */
export function SearchField(props: SearchFieldProps): JSX.Element;
