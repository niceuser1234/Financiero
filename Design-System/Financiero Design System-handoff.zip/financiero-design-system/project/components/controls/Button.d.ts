import * as React from 'react';
import type { IconName } from '../icons/Icon';

export interface ButtonProps extends Omit<React.ButtonHTMLAttributes<HTMLButtonElement>, 'children'> {
  children?: React.ReactNode;
  /** Visual weight. `primary` = filled marine. Default `primary`. */
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  /** Default `md`. */
  size?: 'sm' | 'md' | 'lg';
  /** Optional leading icon. */
  icon?: IconName;
  /** Optional trailing icon. */
  iconRight?: IconName;
  disabled?: boolean;
}

/** Financiero action button — exactly one accent color, soft accent shadow on primary. */
export function Button(props: ButtonProps): JSX.Element;
