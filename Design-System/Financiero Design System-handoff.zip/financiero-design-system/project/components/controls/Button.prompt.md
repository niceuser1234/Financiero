**Button** — Financiero's action button. `primary` is filled marine with a soft accent shadow; use exactly one primary per view. `secondary`/`ghost` for lower-emphasis actions, `danger` for destructive (red text, not red fill).

```jsx
<Button icon="refresh-cw">Jetzt synchronisieren</Button>
<Button variant="secondary" icon="upload">CSV importieren</Button>
<Button variant="ghost" size="sm">Abbrechen</Button>
```

Props: `variant` (primary·secondary·ghost·danger), `size` (sm·md·lg), `icon`/`iconRight` (Lucide id), `disabled`.
