import * as React from 'react';
import type { IconName } from '../icons/Icon';

export interface FilterPillProps {
  children?: React.ReactNode;
  /** Selected/on state — tinted accent-soft background. */
  active?: boolean;
  /** Optional numeric badge on the right. */
  count?: number;
  /** Show a trailing chevron (opens a menu). */
  dropdown?: boolean;
  /** Optional leading icon. */
  icon?: IconName;
  onClick?: () => void;
  style?: React.CSSProperties;
}

/** Rounded filter pill for the Transaktionen filter bar. Toggle + optional count/dropdown. */
export function FilterPill(props: FilterPillProps): JSX.Element;
