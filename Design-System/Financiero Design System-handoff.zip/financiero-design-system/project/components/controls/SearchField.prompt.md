**SearchField** — the transaction search box. Leading magnifier, 3px accent focus ring, trailing ✕ to clear when filled.

```jsx
const [q, setQ] = React.useState('');
<SearchField value={q} onChange={setQ} onClear={() => setQ('')}
  placeholder="Umsätze durchsuchen …" width={360} />
```
