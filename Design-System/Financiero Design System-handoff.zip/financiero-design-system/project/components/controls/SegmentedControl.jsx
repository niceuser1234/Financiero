import React from 'react';

/** iOS-style segmented control. Options = [{value,label}] or string[]. One accent-filled active pill. */
export function SegmentedControl({ options = [], value, onChange, size = 'md', style }) {
  const opts = options.map((o) => (typeof o === 'string' ? { value: o, label: o } : o));
  const pad = size === 'sm' ? '6px 12px' : '8px 16px';
  const font = size === 'sm' ? 12.5 : 13.5;
  return (
    <div style={{
      display: 'inline-flex', padding: 4, gap: 2, background: 'var(--surface)',
      borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-sm)',
      border: '1px solid var(--hairline)', ...style,
    }}>
      {opts.map((o) => {
        const active = o.value === value;
        return (
          <button key={o.value} onClick={() => onChange && onChange(o.value)}
            style={{
              border: 0, cursor: 'pointer', padding: pad, borderRadius: 'var(--radius-sm)',
              font: `${active ? 'var(--fw-semibold)' : 'var(--fw-medium)'} ${font}px/1 var(--font-sans)`,
              background: active ? 'var(--accent)' : 'transparent',
              color: active ? 'var(--accent-fg)' : 'var(--ink-500)',
              boxShadow: active ? 'var(--shadow-accent)' : 'none',
              transition: 'background var(--dur-fast) var(--ease-out), color var(--dur-fast) var(--ease-out)',
              whiteSpace: 'nowrap',
            }}
            onMouseEnter={(e) => { if (!active) e.currentTarget.style.color = 'var(--ink-900)'; }}
            onMouseLeave={(e) => { if (!active) e.currentTarget.style.color = 'var(--ink-500)'; }}
          >{o.label}</button>
        );
      })}
    </div>
  );
}
