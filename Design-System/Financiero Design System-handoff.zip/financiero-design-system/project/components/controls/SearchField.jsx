import React from 'react';
import { Icon } from '../icons/Icon.jsx';

/** Search input with a leading magnifier and focus ring. Clears via the trailing ✕ when filled. */
export function SearchField({ value, onChange, placeholder = 'Suchen …', onClear, width, style }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: 9, width: width || 320,
      padding: '10px 12px', borderRadius: 'var(--radius-md)', background: 'var(--surface)',
      border: `1px solid ${focus ? 'var(--accent)' : 'var(--hairline-strong)'}`,
      boxShadow: focus ? `0 0 0 3px var(--accent-ring)` : 'var(--shadow-xs)',
      transition: 'box-shadow var(--dur-fast) var(--ease-out), border-color var(--dur-fast) var(--ease-out)', ...style,
    }}>
      <Icon name="search" size={17} color="var(--ink-400)" />
      <input
        value={value} placeholder={placeholder}
        onChange={(e) => onChange && onChange(e.target.value)}
        onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
        style={{
          flex: 1, minWidth: 0, border: 0, outline: 'none', background: 'transparent',
          font: `var(--fw-regular) 14px/1 var(--font-sans)`, color: 'var(--ink-900)',
        }}
      />
      {value && (
        <button onClick={onClear} aria-label="Leeren"
          style={{ border: 0, background: 'transparent', cursor: 'pointer', display: 'grid', placeItems: 'center', color: 'var(--ink-400)', padding: 0 }}>
          <Icon name="x" size={15} strokeWidth={2.25} />
        </button>
      )}
    </div>
  );
}
