**FilterPill** — a toggleable rounded pill in the Transaktionen filter bar. Active = tinted `accent-soft`. Optionally shows a result `count` or a `dropdown` chevron (opens a category/date menu).

```jsx
<FilterPill icon="sliders-horizontal">Filter</FilterPill>
<FilterPill dropdown>Kategorie</FilterPill>
<FilterPill active count={12}>Ausgaben</FilterPill>
```
