// Mobile screens — Dashboard & Transaktionen with bottom tab bar.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const { KpiCard, DonutChart, TransactionRow, SearchField, FilterPill, FilterChip, Badge, Icon } = NS;
  const F = window.FIN;

  const scroll = { flex: 1, overflowY: 'auto', padding: '52px 16px 16px' };
  const cardBox = { background: 'var(--surface)', border: '1px solid var(--hairline)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-sm)', padding: 16, marginBottom: 14 };
  const cardTitle = { font: 'var(--fw-semibold) 14px/1 var(--font-sans)', color: 'var(--ink-900)', marginBottom: 14 };

  function MobileHeader({ title, sub }) {
    return (
      <div style={{ marginBottom: 16 }}>
        <div style={{ font: 'var(--fw-bold) 24px/1.1 var(--font-display)', letterSpacing: '-.02em', color: 'var(--ink-900)' }}>{title}</div>
        {sub && <div style={{ font: 'var(--fw-regular) 13px/1.3 var(--font-sans)', color: 'var(--ink-500)', marginTop: 4 }}>{sub}</div>}
      </div>
    );
  }

  function MobileDashboard({ nav, onNav }) {
    const donut = F.catSpend.slice(0, 5).map((c) => ({ label: F.CAT[c.key].label, value: c.value, display: F.fmtEUR(c.value), color: F.CAT[c.key].color }));
    return (
      <React.Fragment>
        <div style={scroll}>
          <MobileHeader title="Hallo, Jonas" sub="Überblick über deine Finanzen." />
          <div style={{ background: 'var(--accent)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-accent)', padding: '18px 20px', marginBottom: 14 }}>
            <div style={{ font: 'var(--fw-semibold) 10.5px/1 var(--font-sans)', letterSpacing: '.09em', textTransform: 'uppercase', color: 'rgba(255,255,255,.72)' }}>Gesamtsaldo</div>
            <div style={{ font: 'var(--fw-bold) 34px/1 var(--font-display)', letterSpacing: '-.02em', color: '#fff', marginTop: 10, fontVariantNumeric: 'tabular-nums' }}>{F.fmtEUR(F.kpis.saldo)}</div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 }}>
            <KpiCard tone="income" label="Einnahmen" value={F.fmtEUR(F.kpis.einnahmen)} />
            <KpiCard tone="expense" label="Ausgaben" value={F.fmtEUR(F.kpis.ausgaben)} />
          </div>
          <div style={cardBox}>
            <div style={cardTitle}>Ausgaben nach Kategorie</div>
            <DonutChart size={130} thickness={20} centerValue={F.fmtEUR(F.kpis.ausgaben).replace(',43 €', ' €')} data={donut} />
          </div>
          <div style={cardBox}>
            <div style={cardTitle}>Letzte Umsätze</div>
            <div style={{ margin: '0 -8px' }}>
              {F.txns.slice(0, 4).map((t) => (
                <TransactionRow key={t.id} name={t.name} meta={F.shortDate(t.date)} amount={F.fmtEUR(t.amount)}
                  direction={t.amount > 0 ? 'income' : 'expense'} recurring={t.recurring} />
              ))}
            </div>
          </div>
        </div>
        <window.MobileTabBar active={nav} onNavigate={onNav} />
      </React.Fragment>
    );
  }

  function MobileTransaktionen({ nav, onNav }) {
    const [q, setQ] = React.useState('');
    const filtered = F.txns.filter((t) => !q || t.name.toLowerCase().includes(q.toLowerCase()));
    const groups = F.groupByDate(filtered);
    return (
      <React.Fragment>
        <div style={scroll}>
          <MobileHeader title="Umsätze" />
          <div style={{ marginBottom: 12 }}>
            <SearchField value={q} onChange={setQ} onClear={() => setQ('')} placeholder="Suchen …" width={'100%'} style={{ width: '100%' }} />
          </div>
          <div style={{ display: 'flex', gap: 8, marginBottom: 12, overflowX: 'auto', paddingBottom: 2 }}>
            <FilterPill active count={filtered.length}>Alle</FilterPill>
            <FilterPill dropdown>Kategorie</FilterPill>
            <FilterPill dropdown>Konto</FilterPill>
          </div>
          <div style={{ display: 'flex', gap: 6, marginBottom: 14 }}>
            <FilterChip label="Konto" value="DKB Girokonto" onRemove={() => {}} />
          </div>
          {groups.map((g) => (
            <div key={g.label} style={cardBox}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 }}>
                <span style={{ font: 'var(--fw-semibold) 11px/1 var(--font-sans)', letterSpacing: '.04em', textTransform: 'uppercase', color: 'var(--ink-400)' }}>{g.label}</span>
                <span style={{ font: 'var(--fw-medium) 12px/1 var(--font-display)', color: 'var(--ink-500)', fontVariantNumeric: 'tabular-nums' }}>{F.fmtEUR(g.sum)}</span>
              </div>
              <div style={{ margin: '0 -8px' }}>
                {g.items.map((t) => (
                  <TransactionRow key={t.id} name={t.name} meta={t.acct} amount={F.fmtEUR(t.amount)}
                    direction={t.amount > 0 ? 'income' : 'expense'} uncategorized={!t.cat} review={t.review} recurring={t.recurring} />
                ))}
              </div>
            </div>
          ))}
        </div>
        <window.MobileTabBar active={nav} onNavigate={onNav} />
      </React.Fragment>
    );
  }

  Object.assign(window, { MobileDashboard, MobileTransaktionen });
})();
