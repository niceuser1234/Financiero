// Analyse screen — period toggle, income/expense KPIs, category donut, 6-month bars, top merchants.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const { Card, KpiCard, DonutChart, BarChart, SegmentedControl, Icon } = NS;
  const F = window.FIN;

  function MerchantRow({ m, i }) {
    const initial = m.name.charAt(0).toUpperCase();
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '12px 0', borderBottom: i < F.topMerchants.length - 1 ? '1px solid var(--hairline)' : 0 }}>
        <span style={{ width: 34, height: 34, borderRadius: 9, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'grid', placeItems: 'center', font: 'var(--fw-semibold) 13px/1 var(--font-sans)', flex: 'none' }}>{initial}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: 'var(--fw-medium) 14px/1.2 var(--font-sans)', color: 'var(--ink-900)' }}>{m.name}</div>
          <div style={{ font: 'var(--fw-regular) 12px/1.2 var(--font-sans)', color: 'var(--ink-400)' }}>{m.count} {m.count === 1 ? 'Buchung' : 'Buchungen'}</div>
        </div>
        <span style={{ font: 'var(--fw-semibold) 14px/1 var(--font-display)', color: 'var(--ink-900)', fontVariantNumeric: 'tabular-nums' }}>{F.fmtEUR(m.amount)}</span>
      </div>
    );
  }

  function Analyse() {
    const [range, setRange] = React.useState('monat');
    const donut = F.catSpend.map((c) => ({ label: F.CAT[c.key].label, value: c.value, display: F.fmtEUR(c.value), color: F.CAT[c.key].color }));
    return (
      <div>
        <window.PageHeader title="Analyse" lead="Wofür dein Geld draufgeht."
          right={<SegmentedControl value={range} onChange={setRange}
            options={[{ value: 'monat', label: 'Monat' }, { value: '3m', label: '3 Monate' }, { value: 'jahr', label: '1 Jahr' }]} />} />

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginBottom: 18 }}>
          <KpiCard tone="income" label="Einnahmen" value={F.fmtEUR(F.kpis.einnahmen)} delta="4,2 % ggü. Vormonat" deltaDir="up" />
          <KpiCard tone="expense" label="Ausgaben" value={F.fmtEUR(F.kpis.ausgaben)} delta="7,3 % ggü. Vormonat" deltaDir="down" />
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1.35fr 1fr', gap: 18, marginBottom: 18 }}>
          <Card title="Ausgaben nach Kategorie" subtitle="Juli 2026">
            <DonutChart size={168} thickness={24} centerValue={F.fmtEUR(F.kpis.ausgaben).replace(',43 €', ' €')} data={donut} />
          </Card>
          <Card title="Top-Händler" subtitle="Nach Ausgaben">
            {F.topMerchants.map((m, i) => <MerchantRow key={m.name} m={m} i={i} />)}
          </Card>
        </div>

        <Card title="Einnahmen vs. Ausgaben" subtitle="Letzte 6 Monate">
          <BarChart highlightLast height={168}
            series={[{ name: 'Einnahmen', color: 'var(--income-mid)' }, { name: 'Ausgaben', color: 'var(--expense)' }]}
            data={F.trend} />
        </Card>
      </div>
    );
  }
  window.Analyse = Analyse;
})();
