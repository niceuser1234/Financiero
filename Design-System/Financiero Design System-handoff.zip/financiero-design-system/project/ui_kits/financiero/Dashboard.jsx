// Dashboard screen.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const { Card, KpiCard, DonutChart, TransactionRow, Badge, Button, Icon } = NS;
  const F = window.FIN;

  function AccountRow({ a }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '13px 0', borderBottom: '1px solid var(--hairline)' }}>
        <span style={{ width: 36, height: 36, borderRadius: 10, background: a.color, color: '#fff', display: 'grid', placeItems: 'center', flex: 'none' }}><Icon name="landmark" size={18} strokeWidth={2} /></span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: 'var(--fw-medium) 14px/1.2 var(--font-sans)', color: 'var(--ink-900)' }}>{a.name}</div>
          <div style={{ font: 'var(--fw-regular) 12px/1.2 var(--font-sans)', color: 'var(--ink-400)', fontVariantNumeric: 'tabular-nums' }}>{a.iban}</div>
        </div>
        <span style={{ font: 'var(--fw-semibold) 15px/1 var(--font-display)', color: 'var(--ink-900)', fontVariantNumeric: 'tabular-nums', letterSpacing: '-.01em' }}>{F.fmtEUR(a.balance)}</span>
      </div>
    );
  }

  function Upcoming({ c }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '11px 0', borderBottom: '1px solid var(--hairline)' }}>
        <span style={{ width: 34, height: 34, borderRadius: 9, background: 'var(--surface-sunken)', color: 'var(--ink-500)', display: 'grid', placeItems: 'center', flex: 'none' }}><Icon name="calendar" size={16} /></span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: 'var(--fw-medium) 13.5px/1.2 var(--font-sans)', color: 'var(--ink-900)' }}>{c.merchant}</div>
          <div style={{ font: 'var(--fw-regular) 11.5px/1.2 var(--font-sans)', color: 'var(--ink-400)' }}>{c.next}</div>
        </div>
        <span style={{ font: 'var(--fw-semibold) 14px/1 var(--font-display)', color: 'var(--ink-900)', fontVariantNumeric: 'tabular-nums' }}>{F.fmtEUR(c.amount)}</span>
      </div>
    );
  }

  function Dashboard() {
    const donut = F.catSpend.slice(0, 6).map((c) => ({ label: F.CAT[c.key].label, value: c.value, display: F.fmtEUR(c.value), color: F.CAT[c.key].color }));
    const recent = F.txns.slice(0, 5);
    const upcoming = F.contracts.filter((c) => c.status === 'aktiv').slice(0, 4);
    return (
      <div>
        <window.PageHeader title="Dashboard" lead="Überblick über deine Finanzen." right={<Button icon="refresh-cw">Jetzt synchronisieren</Button>} />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 18, marginBottom: 18 }}>
          <KpiCard tone="accent" label="Gesamtsaldo" value={F.fmtEUR(F.kpis.saldo)} icon="wallet" />
          <KpiCard tone="income" label="Einnahmen / Monat" value={F.fmtEUR(F.kpis.einnahmen)} delta="4,2 % ggü. Vormonat" deltaDir="up" />
          <KpiCard tone="expense" label="Ausgaben / Monat" value={F.fmtEUR(F.kpis.ausgaben)} delta="7,3 % ggü. Vormonat" deltaDir="down" />
          <KpiCard tone="neutral" label="Abos / Monat" value={F.fmtEUR(F.kpis.abos)} icon="repeat" />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 18, marginBottom: 18 }}>
          <Card title="Ausgaben nach Kategorie" subtitle="Juli 2026">
            <DonutChart size={160} thickness={22} centerValue={F.fmtEUR(2187.43).replace(',43 €', ' €')} data={donut} />
          </Card>
          <Card title="Konten" action={<Button variant="ghost" size="sm" iconRight="chevron-right">Alle</Button>}>
            {F.accounts.map((a) => <AccountRow key={a.id} a={a} />)}
          </Card>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: 18 }}>
          <Card title="Letzte Umsätze" action={<Button variant="ghost" size="sm" iconRight="chevron-right">Alle Umsätze</Button>} bodyStyle={{ margin: '0 -12px' }}>
            {recent.map((t) => (
              <TransactionRow key={t.id} name={t.name} meta={`${t.acct} · ${F.shortDate(t.date)}`}
                amount={F.fmtEUR(t.amount)} direction={t.amount > 0 ? 'income' : 'expense'}
                category={t.cat ? F.CAT[t.cat].label : null} categoryTone={t.cat === 'einkommen' ? 'income' : 'neutral'}
                uncategorized={!t.cat} review={t.review} recurring={t.recurring} />
            ))}
          </Card>
          <Card title="Anstehende Abbuchungen" subtitle="Nächste 14 Tage">
            {upcoming.map((c) => <Upcoming key={c.id} c={c} />)}
          </Card>
        </div>
      </div>
    );
  }
  window.Dashboard = Dashboard;
})();
