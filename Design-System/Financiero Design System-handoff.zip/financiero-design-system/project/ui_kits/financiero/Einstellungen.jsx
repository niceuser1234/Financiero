// Einstellungen screen — Bankverbindungen, CSV-Import, Review-Queue.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const { Card, Badge, Button, Icon, TransactionRow } = NS;
  const F = window.FIN;

  function BankRow({ a, i }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '14px 0', borderBottom: i < F.accounts.length - 1 ? '1px solid var(--hairline)' : 0 }}>
        <span style={{ width: 38, height: 38, borderRadius: 10, background: a.color, color: '#fff', display: 'grid', placeItems: 'center', flex: 'none' }}><Icon name="landmark" size={18} strokeWidth={2} /></span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: 'var(--fw-medium) 14px/1.2 var(--font-sans)', color: 'var(--ink-900)' }}>{a.name}</div>
          <div style={{ font: 'var(--fw-regular) 12px/1.2 var(--font-sans)', color: 'var(--ink-400)', fontVariantNumeric: 'tabular-nums' }}>{a.iban}</div>
        </div>
        <Badge tone="income" icon="circle-check">Verbunden</Badge>
        <button style={{ ...window.iconBtn, width: 34, height: 34 }} title="Optionen"><Icon name="ellipsis" size={18} /></button>
      </div>
    );
  }

  function ReviewRow({ r, i }) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 13, padding: '13px 0', borderBottom: i < F.reviewQueue.length - 1 ? '1px solid var(--hairline)' : 0 }}>
        <span style={{ width: 36, height: 36, borderRadius: 9, background: 'var(--review-soft-bg)', color: 'var(--review)', display: 'grid', placeItems: 'center', flex: 'none' }}><Icon name="triangle-alert" size={17} strokeWidth={2} /></span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ font: 'var(--fw-medium) 14px/1.2 var(--font-sans)', color: 'var(--ink-900)' }}>{r.name}</div>
          <div style={{ font: 'var(--fw-regular) 12px/1.2 var(--font-sans)', color: 'var(--ink-400)' }}>Vorschlag: {r.guess} · {r.acct}</div>
        </div>
        <span style={{ font: 'var(--fw-semibold) 14px/1 var(--font-display)', color: 'var(--ink-900)', fontVariantNumeric: 'tabular-nums', marginRight: 4 }}>{F.fmtEUR(r.amount)}</span>
        <Button size="sm" variant="secondary">Übernehmen</Button>
      </div>
    );
  }

  function Einstellungen() {
    return (
      <div>
        <window.PageHeader title="Einstellungen" lead="Konten, Datenimport und Kategorisierung." />
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18, marginBottom: 18 }}>
          <Card title="Bankverbindungen" action={<Button size="sm" icon="plus">Konto hinzufügen</Button>}>
            {F.accounts.map((a, i) => <BankRow key={a.id} a={a} i={i} />)}
          </Card>
          <Card title="CSV-Import" subtitle="Umsätze aus einer Datei einlesen">
            <div style={{ border: '1.5px dashed var(--hairline-strong)', borderRadius: 'var(--radius-md)', padding: '30px 20px', textAlign: 'center', background: 'var(--surface-raised)' }}>
              <span style={{ display: 'inline-grid', placeItems: 'center', width: 46, height: 46, borderRadius: 12, background: 'var(--accent-soft)', color: 'var(--accent)', marginBottom: 12 }}><Icon name="upload" size={22} /></span>
              <div style={{ font: 'var(--fw-medium) 14px/1.4 var(--font-sans)', color: 'var(--ink-900)' }}>CSV hierher ziehen oder auswählen</div>
              <div style={{ font: 'var(--fw-regular) 12.5px/1.4 var(--font-sans)', color: 'var(--ink-400)', margin: '4px 0 16px' }}>DKB, N26, Sparkasse und weitere Formate</div>
              <Button variant="secondary" icon="file-text">Datei auswählen</Button>
            </div>
          </Card>
        </div>
        <Card title="Review-Queue" subtitle="Von der KI unsicher kategorisiert"
          action={<Badge tone="review">{F.reviewQueue.length} offen</Badge>}>
          {F.reviewQueue.map((r, i) => <ReviewRow key={r.id} r={r} i={i} />)}
        </Card>
      </div>
    );
  }
  window.Einstellungen = Einstellungen;
})();
