// App — wires sidebar nav to desktop screens, plus a mobile preview panel.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const { Sidebar } = NS;

  const SCREENS = {
    dashboard: window.Dashboard,
    transaktionen: window.Transaktionen,
    vertraege: window.Vertraege,
    analyse: window.Analyse,
    einstellungen: window.Einstellungen,
  };
  const TITLES = {
    dashboard: 'Dashboard', transaktionen: 'Transaktionen', vertraege: 'Verträge',
    analyse: 'Analyse', einstellungen: 'Einstellungen',
  };

  function App() {
    const [page, setPage] = React.useState('dashboard');
    const [mobilePage, setMobilePage] = React.useState('dashboard');
    const Screen = SCREENS[page] || window.Dashboard;

    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: 40 }}>
        {/* Desktop app */}
        <div style={{ width: 1440, margin: '0 auto', background: 'var(--bg)', borderRadius: 'var(--radius-xl)', overflow: 'hidden', boxShadow: 'var(--shadow-lg)', display: 'flex', minHeight: 940 }}>
          <Sidebar active={page} onNavigate={setPage} footer={<window.AccountFooter />} style={{ borderRight: '1px solid var(--hairline)' }} />
          <div style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
            <window.Topbar title={TITLES[page]} />
            <main style={{ flex: 1, padding: '32px 42px 56px', overflow: 'hidden' }}>
              <Screen />
            </main>
          </div>
        </div>

        {/* Mobile previews */}
        <div style={{ display: 'flex', gap: 44, justifyContent: 'center', flexWrap: 'wrap', paddingBottom: 20 }}>
          <window.PhoneFrame label="Mobile · Dashboard">
            <window.MobileDashboard nav={mobilePage} onNav={setMobilePage} />
          </window.PhoneFrame>
          <window.PhoneFrame label="Mobile · Transaktionen">
            <window.MobileTransaktionen nav="transaktionen" onNav={() => {}} />
          </window.PhoneFrame>
        </div>
      </div>
    );
  }
  window.FinApp = App;
})();
