// Financiero UI kit — shell chrome (topbar, page header, sidebar footer, mobile tab bar).
const { Icon, Button } = window.FinancieroDesignSystem_854562;

// Top bar: page context left, search-hint + sync + account right.
function Topbar({ title }) {
  return (
    <header style={{
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 42px', height: 72, borderBottom: '1px solid var(--hairline)',
      background: 'var(--bg)', position: 'sticky', top: 0, zIndex: 5,
    }}>
      <div style={{ font: 'var(--fw-semibold) 15px/1 var(--font-sans)', color: 'var(--ink-500)' }}>{title}</div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <button style={iconBtn} title="Benachrichtigungen"><Icon name="bell" size={19} /></button>
        <Button size="sm" icon="refresh-cw">Synchronisieren</Button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 9, paddingLeft: 6 }}>
          <span style={{ width: 34, height: 34, borderRadius: 10, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'grid', placeItems: 'center', font: 'var(--fw-semibold) 13px/1 var(--font-sans)' }}>JM</span>
        </div>
      </div>
    </header>
  );
}
const iconBtn = {
  display: 'grid', placeItems: 'center', width: 38, height: 38, borderRadius: 'var(--radius-md)',
  border: '1px solid var(--hairline-strong)', background: 'var(--surface)', color: 'var(--ink-500)',
  cursor: 'pointer', boxShadow: 'var(--shadow-xs)',
};

// Page header: big h1 + optional lead + right slot (segmented / actions).
function PageHeader({ title, lead, right, style }) {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 20, marginBottom: 26, ...style }}>
      <div>
        <h1 style={{ margin: 0, font: 'var(--fw-bold) var(--text-h1)/1.1 var(--font-display)', letterSpacing: 'var(--tracking-tight)', color: 'var(--ink-900)' }}>{title}</h1>
        {lead && <p style={{ margin: '7px 0 0', font: 'var(--fw-regular) 14.5px/1.4 var(--font-sans)', color: 'var(--ink-500)' }}>{lead}</p>}
      </div>
      {right}
    </div>
  );
}

// Sidebar footer — account chip + sign out.
function AccountFooter() {
  return (
    <div style={{ borderTop: '1px solid var(--hairline)', paddingTop: 14, marginTop: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
      <span style={{ width: 34, height: 34, borderRadius: 10, background: 'var(--accent-soft)', color: 'var(--accent)', display: 'grid', placeItems: 'center', font: 'var(--fw-semibold) 13px/1 var(--font-sans)', flex: 'none' }}>JM</span>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ font: 'var(--fw-semibold) 13px/1.2 var(--font-sans)', color: 'var(--ink-900)' }}>Jonas Müller</div>
        <div style={{ font: 'var(--fw-regular) 11.5px/1.2 var(--font-sans)', color: 'var(--ink-400)' }}>jonas@example.de</div>
      </div>
      <button style={{ ...iconBtn, width: 32, height: 32, border: 0, background: 'transparent', boxShadow: 'none' }} title="Abmelden"><Icon name="log-out" size={17} /></button>
    </div>
  );
}

// Mobile bottom tab bar.
const MOBILE_TABS = [
  { id: 'dashboard', label: 'Start', icon: 'layout-dashboard' },
  { id: 'transaktionen', label: 'Umsätze', icon: 'arrow-left-right' },
  { id: 'analyse', label: 'Analyse', icon: 'pie-chart' },
  { id: 'vertraege', label: 'Verträge', icon: 'repeat' },
];
function MobileTabBar({ active, onNavigate }) {
  return (
    <nav style={{
      display: 'flex', justifyContent: 'space-around', alignItems: 'stretch',
      borderTop: '1px solid var(--hairline)', background: 'var(--surface)',
      paddingBottom: 18, paddingTop: 8,
    }}>
      {MOBILE_TABS.map((t) => {
        const on = t.id === active;
        return (
          <button key={t.id} onClick={() => onNavigate && onNavigate(t.id)}
            style={{
              flex: 1, border: 0, background: 'transparent', cursor: 'pointer',
              display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
              color: on ? 'var(--accent)' : 'var(--ink-400)', padding: '4px 0',
            }}>
            <Icon name={t.icon} size={22} strokeWidth={on ? 2.2 : 1.75} />
            <span style={{ font: `${on ? 'var(--fw-semibold)' : 'var(--fw-medium)'} 10.5px/1 var(--font-sans)` }}>{t.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

// Phone frame for mobile screens.
function PhoneFrame({ children, label }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 14 }}>
      <div style={{
        width: 390, height: 800, borderRadius: 44, background: '#0d0f13', padding: 11,
        boxShadow: 'var(--shadow-lg)', flex: 'none',
      }}>
        <div style={{ width: '100%', height: '100%', borderRadius: 34, overflow: 'hidden', background: 'var(--bg)', position: 'relative', display: 'flex', flexDirection: 'column' }}>
          <div style={{ position: 'absolute', top: 9, left: '50%', transform: 'translateX(-50%)', width: 120, height: 30, borderRadius: 999, background: '#0d0f13', zIndex: 20 }} />
          {children}
        </div>
      </div>
      {label && <span style={{ font: 'var(--fw-medium) 13px/1 var(--font-sans)', color: 'var(--ink-400)' }}>{label}</span>}
    </div>
  );
}

Object.assign(window, { Topbar, PageHeader, AccountFooter, MobileTabBar, PhoneFrame, iconBtn });
