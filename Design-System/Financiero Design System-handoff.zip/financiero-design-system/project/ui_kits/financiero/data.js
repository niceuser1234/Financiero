// Financiero — realistic German sample data (no lorem). Attached to window.FIN.
(function () {
  const CAT = {
    wohnen:       { label: 'Wohnen',        color: 'var(--chart-1)' },
    lebensmittel: { label: 'Lebensmittel',  color: 'var(--chart-2)' },
    mobilitaet:   { label: 'Mobilität',     color: 'var(--chart-3)' },
    freizeit:     { label: 'Freizeit',      color: 'var(--chart-4)' },
    versicherung: { label: 'Versicherung',  color: 'var(--chart-5)' },
    abos:         { label: 'Abos',          color: 'var(--chart-6)' },
    gesundheit:   { label: 'Gesundheit',    color: 'var(--chart-7)' },
    einkommen:    { label: 'Einkommen',     color: 'var(--income-mid)' },
  };

  // Signed euro → "1.043,72 €" / "−9,99 €" / "+3.240,00 €"
  function fmtEUR(n, { sign = false } = {}) {
    const neg = n < 0;
    const s = Math.abs(n).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    const pre = neg ? '−' : (sign ? '+' : '');
    return pre + s + ' €';
  }

  const accounts = [
    { id: 'dkb-giro', name: 'DKB Girokonto', iban: 'DE89 1203 0000 0009 4372', balance: 1043.72, bank: 'DKB', color: 'var(--chart-1)' },
    { id: 'dkb-tg', name: 'DKB Tagesgeld', iban: 'DE21 1203 0000 0088 1200', balance: 12500.00, bank: 'DKB', color: 'var(--chart-6)' },
    { id: 'n26', name: 'N26 Hauptkonto', iban: 'DE10 1001 1001 2620 8155', balance: 328.55, bank: 'N26', color: 'var(--ink-700)' },
  ];

  // txns: amount signed; cat key; recurring/review/uncat flags
  const txns = [
    { id: 1,  date: '2026-07-14', name: 'REWE',                 acct: 'DKB Girokonto', amount: -63.44,  cat: 'lebensmittel' },
    { id: 2,  date: '2026-07-14', name: 'PayPal ·88213',        acct: 'DKB Girokonto', amount: -42.10,  cat: null, review: true },
    { id: 3,  date: '2026-07-12', name: 'DB Fernverkehr',       acct: 'DKB Girokonto', amount: -49.90,  cat: 'mobilitaet' },
    { id: 4,  date: '2026-07-10', name: 'dm-drogerie markt',    acct: 'DKB Girokonto', amount: -21.35,  cat: 'gesundheit' },
    { id: 5,  date: '2026-07-08', name: 'Allianz Versicherung', acct: 'DKB Girokonto', amount: -12.50,  cat: 'versicherung', recurring: true },
    { id: 6,  date: '2026-07-05', name: 'Amazon',               acct: 'N26 Hauptkonto', amount: -34.99, cat: null },
    { id: 7,  date: '2026-07-03', name: 'Testflix',             acct: 'DKB Girokonto', amount: -9.99,   cat: 'abos', recurring: true },
    { id: 8,  date: '2026-07-03', name: 'Spotify',              acct: 'DKB Girokonto', amount: -10.99,  cat: 'abos', recurring: true },
    { id: 9,  date: '2026-07-02', name: 'REWE',                 acct: 'DKB Girokonto', amount: -38.72,  cat: 'lebensmittel' },
    { id: 10, date: '2026-07-01', name: 'Miete Vermieter Weber', acct: 'DKB Girokonto', amount: -890.00, cat: 'wohnen', recurring: true },
    { id: 11, date: '2026-07-01', name: 'Stadtwerke München',   acct: 'DKB Girokonto', amount: -84.00,  cat: 'wohnen', recurring: true },
    { id: 12, date: '2026-06-30', name: 'Gehalt Muster GmbH',   acct: 'DKB Girokonto', amount: 3240.00, cat: 'einkommen', recurring: true },
    { id: 13, date: '2026-06-29', name: 'McFit',                acct: 'N26 Hauptkonto', amount: -24.90, cat: 'gesundheit', recurring: true },
    { id: 14, date: '2026-06-28', name: 'Shell Tankstelle',     acct: 'DKB Girokonto', amount: -71.20,  cat: 'mobilitaet' },
    { id: 15, date: '2026-06-27', name: 'Vodafone',             acct: 'DKB Girokonto', amount: -39.99,  cat: 'abos', recurring: true },
  ];

  // Contracts / recurring
  const contracts = [
    { id: 'miete', name: 'Miete', merchant: 'Vermieter Weber', amount: -890.00, cycle: 'Monatlich', cat: 'wohnen', next: '01.08.2026', status: 'aktiv' },
    { id: 'gehalt', name: 'Gehalt', merchant: 'Muster GmbH', amount: 3240.00, cycle: 'Monatlich', cat: 'einkommen', next: '30.07.2026', status: 'einnahme' },
    { id: 'vodafone', name: 'Mobilfunk', merchant: 'Vodafone', amount: -39.99, cycle: 'Monatlich', cat: 'abos', next: '27.07.2026', status: 'aktiv' },
    { id: 'mcfit', name: 'Fitnessstudio', merchant: 'McFit', amount: -24.90, cycle: 'Monatlich', cat: 'gesundheit', next: '29.07.2026', status: 'aktiv' },
    { id: 'allianz', name: 'Hausratversicherung', merchant: 'Allianz', amount: -12.50, cycle: 'Monatlich', cat: 'versicherung', next: '08.08.2026', status: 'aktiv' },
    { id: 'spotify', name: 'Musik-Streaming', merchant: 'Spotify', amount: -10.99, cycle: 'Monatlich', cat: 'abos', next: '03.08.2026', status: 'aktiv' },
    { id: 'testflix', name: 'Video-Streaming', merchant: 'Testflix', amount: -9.99, cycle: 'Monatlich', cat: 'abos', next: '03.08.2026', status: 'aktiv' },
    { id: 'strom', name: 'Strom', merchant: 'Stadtwerke München', amount: -84.00, cycle: 'Monatlich', cat: 'wohnen', next: '01.08.2026', status: 'aktiv' },
    { id: 'dazn', name: 'Sport-Streaming', merchant: 'DAZN', amount: -34.99, cycle: 'Monatlich', cat: 'abos', next: '—', status: 'beendet' },
  ];

  // Category spend for current month (Ausgaben nach Kategorie)
  const catSpend = [
    { key: 'wohnen', value: 974.00 },
    { key: 'lebensmittel', value: 412.30 },
    { key: 'mobilitaet', value: 310.56 },
    { key: 'freizeit', value: 168.90 },
    { key: 'versicherung', value: 145.20 },
    { key: 'abos', value: 95.96 },
    { key: 'gesundheit', value: 80.51 },
  ];

  // 6-month income vs expense
  const trend = [
    { label: 'Feb', values: [3180, 2210] },
    { label: 'Mär', values: [3240, 2540] },
    { label: 'Apr', values: [3240, 2080] },
    { label: 'Mai', values: [3390, 2450] },
    { label: 'Jun', values: [3240, 2360] },
    { label: 'Jul', values: [3240, 2187] },
  ];

  const topMerchants = [
    { name: 'Vermieter Weber', count: 1, amount: -890.00 },
    { name: 'REWE', count: 6, amount: -238.44 },
    { name: 'Stadtwerke München', count: 1, amount: -84.00 },
    { name: 'Shell Tankstelle', count: 2, amount: -71.20 },
    { name: 'Amazon', count: 4, amount: -96.30 },
  ];

  const reviewQueue = [
    { id: 'r1', name: 'PayPal ·88213', amount: -42.10, guess: 'Freizeit', acct: 'DKB Girokonto' },
    { id: 'r2', name: 'Amazon', amount: -34.99, guess: 'Sonstiges', acct: 'N26 Hauptkonto' },
    { id: 'r3', name: 'SumUp ·Café Ost', amount: -8.40, guess: 'Lebensmittel', acct: 'DKB Girokonto' },
  ];

  const kpis = {
    saldo: 13872.27,
    einnahmen: 3240.00,
    ausgaben: 2187.43,
    abos: 233.35,
  };

  // group txns by date, German heading
  function groupByDate(list) {
    const months = ['Jan.','Feb.','März','Apr.','Mai','Juni','Juli','Aug.','Sep.','Okt.','Nov.','Dez.'];
    const groups = {};
    list.forEach((t) => {
      const [y, m, d] = t.date.split('-').map(Number);
      const key = `${String(d).padStart(2, '0')}. ${months[m - 1]} ${y}`;
      (groups[key] = groups[key] || []).push(t);
    });
    return Object.entries(groups).map(([label, items]) => ({
      label,
      items,
      sum: items.reduce((s, t) => s + t.amount, 0),
    }));
  }

  function shortDate(iso) {
    const [, m, d] = iso.split('-');
    return `${d}.${m}.`;
  }

  window.FIN = { CAT, fmtEUR, accounts, txns, contracts, catSpend, trend, topMerchants, reviewQueue, kpis, groupByDate, shortDate };
})();
