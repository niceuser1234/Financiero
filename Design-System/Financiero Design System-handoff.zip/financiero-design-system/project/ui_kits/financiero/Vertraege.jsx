// Verträge screen — summary card, status segmented, contract cards. (Airier layout.)
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const { Card, KpiCard, SegmentedControl, Badge, Icon, Button } = NS;
  const F = window.FIN;

  function ContractCard({ c }) {
    const income = c.amount > 0;
    return (
      <div style={{ display: 'flex', alignItems: 'center', gap: 18, padding: '24px 26px', background: 'var(--surface)', border: '1px solid var(--hairline)', borderRadius: 'var(--radius-lg)', boxShadow: 'var(--shadow-md)' }}>
        <span style={{ width: 50, height: 50, borderRadius: 13, background: income ? 'var(--income-soft-bg)' : 'var(--accent-soft)', color: income ? 'var(--income)' : 'var(--accent)', display: 'grid', placeItems: 'center', font: 'var(--fw-semibold) 17px/1 var(--font-sans)', flex: 'none' }}>{c.merchant.charAt(0)}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
            <span style={{ font: 'var(--fw-semibold) 16px/1.2 var(--font-sans)', color: 'var(--ink-900)' }}>{c.merchant}</span>
            <Badge tone="neutral" icon="repeat">{c.cycle}</Badge>
          </div>
          <div style={{ font: 'var(--fw-regular) 13.5px/1.3 var(--font-sans)', color: 'var(--ink-500)', marginTop: 6 }}>{c.name} · nächste Buchung am {c.next}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ font: 'var(--fw-bold) 20px/1 var(--font-display)', color: income ? 'var(--income)' : 'var(--ink-900)', fontVariantNumeric: 'tabular-nums', letterSpacing: '-.01em' }}>{F.fmtEUR(c.amount)}</div>
          <div style={{ font: 'var(--fw-medium) 12px/1 var(--font-sans)', color: 'var(--ink-400)', marginTop: 7 }}>pro Monat</div>
        </div>
        <button style={{ ...window.iconBtn, width: 40, height: 40, marginLeft: 4 }} title="Optionen"><Icon name="ellipsis" size={18} /></button>
      </div>
    );
  }

  function Vertraege() {
    const [tab, setTab] = React.useState('aktiv');
    const list = F.contracts.filter((c) => c.status === tab);
    const monthly = F.contracts.filter((c) => c.status === 'aktiv').reduce((s, c) => s + c.amount, 0);
    const activeCount = F.contracts.filter((c) => c.status === 'aktiv').length;
    return (
      <div>
        <window.PageHeader title="Verträge" lead="Wiederkehrende Buchungen und Abos im Überblick." style={{ marginBottom: 32 }} />
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3,1fr)', gap: 20, marginBottom: 36 }}>
          <KpiCard tone="neutral" label="Fixkosten / Monat" value={F.fmtEUR(monthly)} icon="repeat" />
          <KpiCard tone="neutral" label="Aktive Verträge" value={String(activeCount)} icon="credit-card" />
          <KpiCard tone="income" label="Einnahmen / Monat" value={F.fmtEUR(F.kpis.einnahmen)} icon="trending-up" />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
          <SegmentedControl value={tab} onChange={setTab}
            options={[{ value: 'aktiv', label: 'Aktiv' }, { value: 'einnahme', label: 'Einnahmen' }, { value: 'beendet', label: 'Beendet' }]} />
          <span style={{ font: 'var(--fw-medium) 13px/1 var(--font-sans)', color: 'var(--ink-400)' }}>{list.length} {list.length === 1 ? 'Vertrag' : 'Verträge'}</span>
        </div>
        {list.length === 0
          ? <Card><NS.EmptyState icon="repeat" title="Nichts hier" message="Keine Verträge in dieser Ansicht." /></Card>
          : <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>{list.map((c) => <ContractCard key={c.id} c={c} />)}</div>}
      </div>
    );
  }
  window.Vertraege = Vertraege;
})();
