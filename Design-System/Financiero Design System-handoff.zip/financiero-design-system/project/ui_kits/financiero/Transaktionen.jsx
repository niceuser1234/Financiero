// Transaktionen screen — search, filters, active chips, date groups, sum row.
(function () {
  const NS = window.FinancieroDesignSystem_854562;
  const { Card, TransactionRow, SearchField, FilterPill, FilterChip, SegmentedControl, Button } = NS;
  const F = window.FIN;

  function Transaktionen() {
    const [q, setQ] = React.useState('');
    const [chips, setChips] = React.useState([
      { id: 'konto', label: 'Konto', value: 'DKB Girokonto' },
      { id: 'zeit', label: 'Zeitraum', value: 'Juli 2026' },
    ]);
    const remove = (id) => setChips((c) => c.filter((x) => x.id !== id));

    const filtered = F.txns.filter((t) => !q || t.name.toLowerCase().includes(q.toLowerCase()));
    const groups = F.groupByDate(filtered);
    const total = filtered.reduce((s, t) => s + t.amount, 0);

    return (
      <div>
        <window.PageHeader title="Transaktionen" lead={`${filtered.length} Umsätze · ${F.fmtEUR(total)}`}
          right={<Button variant="secondary" icon="upload">CSV importieren</Button>} />

        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14, flexWrap: 'wrap' }}>
          <SearchField value={q} onChange={setQ} onClear={() => setQ('')} placeholder="Umsätze durchsuchen …" width={340} />
          <div style={{ flex: 1 }} />
          <FilterPill icon="sliders-horizontal">Filter</FilterPill>
          <FilterPill dropdown>Kategorie</FilterPill>
          <FilterPill dropdown>Konto</FilterPill>
          <SegmentedControl value="alle" onChange={() => {}} size="sm"
            options={[{ value: 'alle', label: 'Alle' }, { value: 'aus', label: 'Ausgaben' }, { value: 'ein', label: 'Einnahmen' }]} />
        </div>

        {chips.length > 0 && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
            <span style={{ font: 'var(--fw-medium) 12px/1 var(--font-sans)', color: 'var(--ink-400)' }}>Aktive Filter:</span>
            {chips.map((c) => <FilterChip key={c.id} label={c.label} value={c.value} onRemove={() => remove(c.id)} />)}
            <button onClick={() => setChips([])} style={{ border: 0, background: 'transparent', cursor: 'pointer', font: 'var(--fw-medium) 12px/1 var(--font-sans)', color: 'var(--accent)', padding: '6px 4px' }}>Alle zurücksetzen</button>
          </div>
        )}

        <Card style={{ padding: '8px 12px' }} bodyStyle={{}}>
          {groups.length === 0 && (
            <NS.EmptyState icon="search" title="Keine Treffer" message={`Für „${q}" wurden keine Umsätze gefunden.`} />
          )}
          {groups.map((g) => (
            <div key={g.label}>
              <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', padding: '16px 12px 6px' }}>
                <span style={{ font: 'var(--fw-semibold) 12px/1 var(--font-sans)', letterSpacing: '.04em', textTransform: 'uppercase', color: 'var(--ink-400)' }}>{g.label}</span>
                <span style={{ font: 'var(--fw-medium) 12.5px/1 var(--font-display)', color: 'var(--ink-500)', fontVariantNumeric: 'tabular-nums' }}>{F.fmtEUR(g.sum)}</span>
              </div>
              {g.items.map((t) => (
                <TransactionRow key={t.id} name={t.name} meta={`${t.acct} · ${F.shortDate(t.date)}`}
                  amount={F.fmtEUR(t.amount)} direction={t.amount > 0 ? 'income' : 'expense'}
                  category={t.cat ? F.CAT[t.cat].label : null} categoryTone={t.cat === 'einkommen' ? 'income' : 'neutral'}
                  uncategorized={!t.cat} review={t.review} recurring={t.recurring} />
              ))}
            </div>
          ))}
        </Card>
      </div>
    );
  }
  window.Transaktionen = Transaktionen;
})();
