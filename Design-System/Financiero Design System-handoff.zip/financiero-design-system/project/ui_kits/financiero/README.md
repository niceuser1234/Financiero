# Financiero — UI Kit

High-fidelity click-through recreation of the Financiero personal-finance app, built from the design system's own components. Information architecture matches the app exactly.

## Run
Open `index.html`. It loads the compiled bundle (`../../_ds_bundle.js`), `styles.css`, sample data, then the screen files.

## Files
- `data.js` — realistic German sample data on `window.FIN` (accounts, transactions, contracts, category spend, 6-month trend, top merchants, review queue) + `fmtEUR` and date helpers. No lorem.
- `Shell.jsx` — chrome: `Topbar`, `PageHeader`, `AccountFooter`, `MobileTabBar`, `PhoneFrame`.
- Desktop screens: `Dashboard.jsx`, `Transaktionen.jsx`, `Analyse.jsx`, `Vertraege.jsx`, `Einstellungen.jsx`.
- `Mobile.jsx` — `MobileDashboard`, `MobileTransaktionen` (bottom tab bar instead of sidebar).
- `app.jsx` — wires the sidebar to the desktop screens and shows the two phones below.

## Screens
- **Dashboard** — KPI row (Gesamtsaldo · Einnahmen · Ausgaben · Abos), Ausgaben nach Kategorie (donut), Konten, letzte Umsätze, anstehende Abbuchungen.
- **Transaktionen** — Suche, Filter-Pills, aktive Filter-Chips, Datumsgruppen mit Summenzeile, leere-Treffer-State.
- **Analyse** — Zeitraum-Toggle, Einnahmen/Ausgaben-KPIs, Kategorie-Donut, Einnahmen vs. Ausgaben (6 Monate), Top-Händler.
- **Verträge** — Fixkosten-Zusammenfassung, Status-Segmented (Aktiv/Einnahmen/Beendet), Vertragskarten.
- **Einstellungen** — Bankverbindungen, CSV-Import (Dropzone), Review-Queue.
- **Mobile** — Dashboard & Transaktionen with a 4-item bottom tab bar.

Screens compose the design system primitives (Sidebar, Card, KpiCard, TransactionRow, DonutChart, BarChart, SegmentedControl, FilterPill, FilterChip, SearchField, Badge, Button, EmptyState, Icon) — they do not re-implement them.
